/******************************************************************************
** uathreedvector.h
**
** Copyright (c) 2006-2022 Unified Automation GmbH. All rights reserved.
**
** Software License Agreement ("SLA") Version 2.7
**
** Unless explicitly acquired and licensed from Licensor under another
** license, the contents of this file are subject to the Software License
** Agreement ("SLA") Version 2.7, or subsequent versions
** as allowed by the SLA, and You may not copy or use this file in either
** source code or executable form, except in compliance with the terms and
** conditions of the SLA.
**
** All software distributed under the SLA is provided strictly on an
** "AS IS" basis, WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESS OR IMPLIED,
** AND LICENSOR HEREBY DISCLAIMS ALL SUCH WARRANTIES, INCLUDING WITHOUT
** LIMITATION, ANY WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
** PURPOSE, QUIET ENJOYMENT, OR NON-INFRINGEMENT. See the SLA for specific
** language governing rights and limitations under the SLA.
**
** The complete license agreement can be found here:
** http://unifiedautomation.com/License/SLA/2.7/
**
** Project: C++ OPC SDK base module
**
** Portable UaThreeDVector class.
**
******************************************************************************/
#ifndef UATHREEDVECTOR_H
#define UATHREEDVECTOR_H

#include <opcua_proxystub.h>

#include "uabase.h"
#include "uaarraytemplates.h"

class UaExtensionObject;
class UaVariant;
class UaDataValue;

class UABASE_EXPORT UaThreeDVectorPrivate;

/** @ingroup CppBaseLibraryClass
 *  @brief Wrapper class for the UA stack structure OpcUa_ThreeDVector.
 *
 *  This class encapsulates the native OpcUa_ThreeDVector structure
 *  and handles memory allocation and cleanup for you.
 *  UaThreeDVector uses implicit sharing to avoid needless copying and to boost the performance.
 *  Only if you modify a shared ThreeDVector it creates a copy for that (copy-on-write).
 *  So assigning another UaThreeDVector or passing it as parameter needs constant time and is nearly as fast as assigning a pointer.
 */
class UABASE_EXPORT UaThreeDVector
{
    UA_DECLARE_PRIVATE(UaThreeDVector)
public:
    UaThreeDVector();
    UaThreeDVector(const UaThreeDVector &other);
    UaThreeDVector(const OpcUa_ThreeDVector &other);
    UaThreeDVector(
        OpcUa_Double x,
        OpcUa_Double y,
        OpcUa_Double z
        );
    UaThreeDVector(const UaExtensionObject &extensionObject);
    UaThreeDVector(const OpcUa_ExtensionObject &extensionObject);
    UaThreeDVector(UaExtensionObject &extensionObject, OpcUa_Boolean bDetach);
    UaThreeDVector(OpcUa_ExtensionObject &extensionObject, OpcUa_Boolean bDetach);
    ~UaThreeDVector();

    void clear();

    bool operator==(const UaThreeDVector &other) const;
    bool operator!=(const UaThreeDVector &other) const;

    UaThreeDVector& operator=(const UaThreeDVector &other);

    OpcUa_ThreeDVector* copy() const;
    void copyTo(OpcUa_ThreeDVector *pDst) const;

    static OpcUa_ThreeDVector* clone(const OpcUa_ThreeDVector& source);
    static void cloneTo(const OpcUa_ThreeDVector& source, OpcUa_ThreeDVector& copy);

    void attach(OpcUa_ThreeDVector *pValue);
    OpcUa_ThreeDVector* detach(OpcUa_ThreeDVector* pDst);

    void toVariant(UaVariant &variant) const;
    void toVariant(OpcUa_Variant &variant) const;
    void toVariant(UaVariant &variant, OpcUa_Boolean bDetach);
    void toVariant(OpcUa_Variant &variant, OpcUa_Boolean bDetach);

    void toDataValue(UaDataValue &dataValue, OpcUa_Boolean updateTimeStamps) const;
    void toDataValue(OpcUa_DataValue &dataValue, OpcUa_Boolean updateTimeStamps) const;
    void toDataValue(UaDataValue &dataValue, OpcUa_Boolean bDetach, OpcUa_Boolean updateTimeStamps);
    void toDataValue(OpcUa_DataValue &dataValue, OpcUa_Boolean bDetach, OpcUa_Boolean updateTimeStamps);

    void toExtensionObject(UaExtensionObject &extensionObject) const;
    void toExtensionObject(OpcUa_ExtensionObject &extensionObject) const;
    void toExtensionObject(UaExtensionObject &extensionObject, OpcUa_Boolean bDetach);
    void toExtensionObject(OpcUa_ExtensionObject &extensionObject, OpcUa_Boolean bDetach);

    OpcUa_StatusCode setThreeDVector(const UaExtensionObject &extensionObject);
    OpcUa_StatusCode setThreeDVector(const OpcUa_ExtensionObject &extensionObject);
    OpcUa_StatusCode setThreeDVector(UaExtensionObject &extensionObject, OpcUa_Boolean bDetach);
    OpcUa_StatusCode setThreeDVector(OpcUa_ExtensionObject &extensionObject, OpcUa_Boolean bDetach);

    void setThreeDVector(
        OpcUa_Double x,
        OpcUa_Double y,
        OpcUa_Double z
        );

    OpcUa_Double getX() const;
    OpcUa_Double getY() const;
    OpcUa_Double getZ() const;

    void setX(OpcUa_Double x);
    void setY(OpcUa_Double y);
    void setZ(OpcUa_Double z);
};

/** @ingroup CppBaseLibraryClass
 *  @brief Array class for the UA stack structure OpcUa_ThreeDVector.
 *
 *  This class encapsulates an array of the native OpcUa_ThreeDVector structure
 *  and handles memory allocation and cleanup for you.
 *  @see UaThreeDVector for information about the encapsulated structure.
 */
class UABASE_EXPORT UaThreeDVectors
{
public:
    UaThreeDVectors();
    UaThreeDVectors(const UaThreeDVectors &other);
    UaThreeDVectors(OpcUa_Int32 length, OpcUa_ThreeDVector* data);
    virtual ~UaThreeDVectors();

    UaThreeDVectors& operator=(const UaThreeDVectors &other);
    const OpcUa_ThreeDVector& operator[](OpcUa_UInt32 index) const;
    OpcUa_ThreeDVector& operator[](OpcUa_UInt32 index);

    bool operator==(const UaThreeDVectors &other) const;
    bool operator!=(const UaThreeDVectors &other) const;

    void attach(OpcUa_UInt32 length, OpcUa_ThreeDVector* data);
    void attach(OpcUa_Int32 length, OpcUa_ThreeDVector* data);
    OpcUa_ThreeDVector* detach();

    void create(OpcUa_UInt32 length);
    void resize(OpcUa_UInt32 length);
    void clear();

    inline OpcUa_UInt32 length() const {return m_noOfElements;}
    inline const OpcUa_ThreeDVector* rawData() const {return m_data;}
    inline OpcUa_ThreeDVector* rawData() {return m_data;}

    void toVariant(UaVariant &variant) const;
    void toVariant(OpcUa_Variant &variant) const;
    void toVariant(UaVariant &variant, OpcUa_Boolean bDetach);
    void toVariant(OpcUa_Variant &variant, OpcUa_Boolean bDetach);

    void toDataValue(UaDataValue &dataValue, OpcUa_Boolean updateTimeStamps) const;
    void toDataValue(OpcUa_DataValue &dataValue, OpcUa_Boolean updateTimeStamps) const;
    void toDataValue(UaDataValue &dataValue, OpcUa_Boolean bDetach, OpcUa_Boolean updateTimeStamps);
    void toDataValue(OpcUa_DataValue &dataValue, OpcUa_Boolean bDetach, OpcUa_Boolean updateTimeStamps);

    OpcUa_StatusCode setThreeDVectors(const UaVariant &variant);
    OpcUa_StatusCode setThreeDVectors(const OpcUa_Variant &variant);
    OpcUa_StatusCode setThreeDVectors(UaVariant &variant, OpcUa_Boolean bDetach);
    OpcUa_StatusCode setThreeDVectors(OpcUa_Variant &variant, OpcUa_Boolean bDetach);
    OpcUa_StatusCode setThreeDVectors(OpcUa_Int32 length, OpcUa_ThreeDVector* data);

private:
    OpcUa_UInt32 m_noOfElements;
    OpcUa_ThreeDVector* m_data;
};

#endif // UATHREEDVECTOR_H

