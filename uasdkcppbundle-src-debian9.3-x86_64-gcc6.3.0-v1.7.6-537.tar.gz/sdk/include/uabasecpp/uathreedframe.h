/******************************************************************************
** uathreedframe.h
**
** Copyright (c) 2006-2022 Unified Automation GmbH. All rights reserved.
**
** Software License Agreement ("SLA") Version 2.7
**
** Unless explicitly acquired and licensed from Licensor under another
** license, the contents of this file are subject to the Software License
** Agreement ("SLA") Version 2.7, or subsequent versions
** as allowed by the SLA, and You may not copy or use this file in either
** source code or executable form, except in compliance with the terms and
** conditions of the SLA.
**
** All software distributed under the SLA is provided strictly on an
** "AS IS" basis, WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESS OR IMPLIED,
** AND LICENSOR HEREBY DISCLAIMS ALL SUCH WARRANTIES, INCLUDING WITHOUT
** LIMITATION, ANY WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
** PURPOSE, QUIET ENJOYMENT, OR NON-INFRINGEMENT. See the SLA for specific
** language governing rights and limitations under the SLA.
**
** The complete license agreement can be found here:
** http://unifiedautomation.com/License/SLA/2.7/
**
** Project: C++ OPC SDK base module
**
** Portable UaThreeDFrame class.
**
******************************************************************************/
#ifndef UATHREEDFRAME_H
#define UATHREEDFRAME_H

#include <opcua_proxystub.h>

#include "uabase.h"
#include "uathreedcartesiancoordinates.h"
#include "uathreedorientation.h"
#include "uaarraytemplates.h"

class UaExtensionObject;
class UaVariant;
class UaDataValue;

class UABASE_EXPORT UaThreeDFramePrivate;

/** @ingroup CppBaseLibraryClass
 *  @brief Wrapper class for the UA stack structure OpcUa_ThreeDFrame.
 *
 *  This class encapsulates the native OpcUa_ThreeDFrame structure
 *  and handles memory allocation and cleanup for you.
 *  UaThreeDFrame uses implicit sharing to avoid needless copying and to boost the performance.
 *  Only if you modify a shared ThreeDFrame it creates a copy for that (copy-on-write).
 *  So assigning another UaThreeDFrame or passing it as parameter needs constant time and is nearly as fast as assigning a pointer.
 */
class UABASE_EXPORT UaThreeDFrame
{
    UA_DECLARE_PRIVATE(UaThreeDFrame)
public:
    UaThreeDFrame();
    UaThreeDFrame(const UaThreeDFrame &other);
    UaThreeDFrame(const OpcUa_ThreeDFrame &other);
    UaThreeDFrame(
        const UaThreeDCartesianCoordinates& cartesianCoordinates,
        const UaThreeDOrientation& orientation
        );
    UaThreeDFrame(const UaExtensionObject &extensionObject);
    UaThreeDFrame(const OpcUa_ExtensionObject &extensionObject);
    UaThreeDFrame(UaExtensionObject &extensionObject, OpcUa_Boolean bDetach);
    UaThreeDFrame(OpcUa_ExtensionObject &extensionObject, OpcUa_Boolean bDetach);
    ~UaThreeDFrame();

    void clear();

    bool operator==(const UaThreeDFrame &other) const;
    bool operator!=(const UaThreeDFrame &other) const;

    UaThreeDFrame& operator=(const UaThreeDFrame &other);

    OpcUa_ThreeDFrame* copy() const;
    void copyTo(OpcUa_ThreeDFrame *pDst) const;

    static OpcUa_ThreeDFrame* clone(const OpcUa_ThreeDFrame& source);
    static void cloneTo(const OpcUa_ThreeDFrame& source, OpcUa_ThreeDFrame& copy);

    void attach(OpcUa_ThreeDFrame *pValue);
    OpcUa_ThreeDFrame* detach(OpcUa_ThreeDFrame* pDst);

    void toVariant(UaVariant &variant) const;
    void toVariant(OpcUa_Variant &variant) const;
    void toVariant(UaVariant &variant, OpcUa_Boolean bDetach);
    void toVariant(OpcUa_Variant &variant, OpcUa_Boolean bDetach);

    void toDataValue(UaDataValue &dataValue, OpcUa_Boolean updateTimeStamps) const;
    void toDataValue(OpcUa_DataValue &dataValue, OpcUa_Boolean updateTimeStamps) const;
    void toDataValue(UaDataValue &dataValue, OpcUa_Boolean bDetach, OpcUa_Boolean updateTimeStamps);
    void toDataValue(OpcUa_DataValue &dataValue, OpcUa_Boolean bDetach, OpcUa_Boolean updateTimeStamps);

    void toExtensionObject(UaExtensionObject &extensionObject) const;
    void toExtensionObject(OpcUa_ExtensionObject &extensionObject) const;
    void toExtensionObject(UaExtensionObject &extensionObject, OpcUa_Boolean bDetach);
    void toExtensionObject(OpcUa_ExtensionObject &extensionObject, OpcUa_Boolean bDetach);

    OpcUa_StatusCode setThreeDFrame(const UaExtensionObject &extensionObject);
    OpcUa_StatusCode setThreeDFrame(const OpcUa_ExtensionObject &extensionObject);
    OpcUa_StatusCode setThreeDFrame(UaExtensionObject &extensionObject, OpcUa_Boolean bDetach);
    OpcUa_StatusCode setThreeDFrame(OpcUa_ExtensionObject &extensionObject, OpcUa_Boolean bDetach);

    void setThreeDFrame(
        const UaThreeDCartesianCoordinates& cartesianCoordinates,
        const UaThreeDOrientation& orientation
        );

    UaThreeDCartesianCoordinates getCartesianCoordinates() const;
    UaThreeDOrientation getOrientation() const;

    void setCartesianCoordinates(const UaThreeDCartesianCoordinates& cartesianCoordinates);
    void setOrientation(const UaThreeDOrientation& orientation);
};

/** @ingroup CppBaseLibraryClass
 *  @brief Array class for the UA stack structure OpcUa_ThreeDFrame.
 *
 *  This class encapsulates an array of the native OpcUa_ThreeDFrame structure
 *  and handles memory allocation and cleanup for you.
 *  @see UaThreeDFrame for information about the encapsulated structure.
 */
class UABASE_EXPORT UaThreeDFrames
{
public:
    UaThreeDFrames();
    UaThreeDFrames(const UaThreeDFrames &other);
    UaThreeDFrames(OpcUa_Int32 length, OpcUa_ThreeDFrame* data);
    virtual ~UaThreeDFrames();

    UaThreeDFrames& operator=(const UaThreeDFrames &other);
    const OpcUa_ThreeDFrame& operator[](OpcUa_UInt32 index) const;
    OpcUa_ThreeDFrame& operator[](OpcUa_UInt32 index);

    bool operator==(const UaThreeDFrames &other) const;
    bool operator!=(const UaThreeDFrames &other) const;

    void attach(OpcUa_UInt32 length, OpcUa_ThreeDFrame* data);
    void attach(OpcUa_Int32 length, OpcUa_ThreeDFrame* data);
    OpcUa_ThreeDFrame* detach();

    void create(OpcUa_UInt32 length);
    void resize(OpcUa_UInt32 length);
    void clear();

    inline OpcUa_UInt32 length() const {return m_noOfElements;}
    inline const OpcUa_ThreeDFrame* rawData() const {return m_data;}
    inline OpcUa_ThreeDFrame* rawData() {return m_data;}

    void toVariant(UaVariant &variant) const;
    void toVariant(OpcUa_Variant &variant) const;
    void toVariant(UaVariant &variant, OpcUa_Boolean bDetach);
    void toVariant(OpcUa_Variant &variant, OpcUa_Boolean bDetach);

    void toDataValue(UaDataValue &dataValue, OpcUa_Boolean updateTimeStamps) const;
    void toDataValue(OpcUa_DataValue &dataValue, OpcUa_Boolean updateTimeStamps) const;
    void toDataValue(UaDataValue &dataValue, OpcUa_Boolean bDetach, OpcUa_Boolean updateTimeStamps);
    void toDataValue(OpcUa_DataValue &dataValue, OpcUa_Boolean bDetach, OpcUa_Boolean updateTimeStamps);

    OpcUa_StatusCode setThreeDFrames(const UaVariant &variant);
    OpcUa_StatusCode setThreeDFrames(const OpcUa_Variant &variant);
    OpcUa_StatusCode setThreeDFrames(UaVariant &variant, OpcUa_Boolean bDetach);
    OpcUa_StatusCode setThreeDFrames(OpcUa_Variant &variant, OpcUa_Boolean bDetach);
    OpcUa_StatusCode setThreeDFrames(OpcUa_Int32 length, OpcUa_ThreeDFrame* data);

private:
    OpcUa_UInt32 m_noOfElements;
    OpcUa_ThreeDFrame* m_data;
};

#endif // UATHREEDFRAME_H

