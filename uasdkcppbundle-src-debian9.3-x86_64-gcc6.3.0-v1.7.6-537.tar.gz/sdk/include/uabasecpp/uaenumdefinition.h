/******************************************************************************
** uaenumdefinition.h
**
** Copyright (c) 2006-2022 Unified Automation GmbH. All rights reserved.
**
** Software License Agreement ("SLA") Version 2.7
**
** Unless explicitly acquired and licensed from Licensor under another
** license, the contents of this file are subject to the Software License
** Agreement ("SLA") Version 2.7, or subsequent versions
** as allowed by the SLA, and You may not copy or use this file in either
** source code or executable form, except in compliance with the terms and
** conditions of the SLA.
**
** All software distributed under the SLA is provided strictly on an
** "AS IS" basis, WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESS OR IMPLIED,
** AND LICENSOR HEREBY DISCLAIMS ALL SUCH WARRANTIES, INCLUDING WITHOUT
** LIMITATION, ANY WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
** PURPOSE, QUIET ENJOYMENT, OR NON-INFRINGEMENT. See the SLA for specific
** language governing rights and limitations under the SLA.
**
** The complete license agreement can be found here:
** http://unifiedautomation.com/License/SLA/2.7/
**
** Project: C++ OPC SDK base module
**
******************************************************************************/
#ifndef UAENUMDEFINITION_H
#define UAENUMDEFINITION_H

#include "uaabstractdefinition.h"
#include "uaenumvalue.h"
#include "uaenumdefinitiondatatype.h"

/** Manages the description for an enumeration DataType.
 *
 * Enumerations provide string representations of numeric values but the
 * transport of the value is always done with the built-in data type Int32.
 *
 * Each UaEnumValue is described by its name amd its integer value.
 *
 * Enumerated DataTypes can be described using this class.
 * This class can be used to add an enumerated DataType on server side as well as a description
 * of available DataTypes in a server on client side.
 */
class UABASE_EXPORT UaEnumDefinition : public UaAbstractDefinition
{
public:
    UaEnumDefinition();
    UaEnumDefinition(const UaEnumDefinition &other);
    UaEnumDefinition(const OpcUa_EnumDefinition *other, const UaNodeId &typeId);

    UaEnumDefinition& operator=(const UaEnumDefinition &other);

    bool operator==(const UaEnumDefinition &other) const;
    bool operator!=(const UaEnumDefinition &other) const;

    // UaAbstractDefinition interface
    virtual UaDataTypeDictionary::DefinitionType definitionType() const { return UaDataTypeDictionary::DefinitionType_Enum; }
    virtual int childrenCount() const;
    virtual void clear();
    virtual bool isNull() const;

    UaEnumValue child(int i) const;
    void addChild(const UaEnumValue &newChild);

    UaEnumValue enumValue(int iValue) const;

    UaEnumDefinition mapNamespaces(NamespaceMappingInterface *pMapper) const;

    UaEnumDefinitionDataType getEnumDefinitionDataType() const;

protected:
    virtual UaAbstractDefinitionPrivate* copyPrivate();
};

#endif // UAENUMDEFINITION_H
