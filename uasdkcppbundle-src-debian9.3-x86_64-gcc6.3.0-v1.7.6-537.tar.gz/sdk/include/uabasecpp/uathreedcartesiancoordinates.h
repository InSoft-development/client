/******************************************************************************
** uathreedcartesiancoordinates.h
**
** Copyright (c) 2006-2022 Unified Automation GmbH. All rights reserved.
**
** Software License Agreement ("SLA") Version 2.7
**
** Unless explicitly acquired and licensed from Licensor under another
** license, the contents of this file are subject to the Software License
** Agreement ("SLA") Version 2.7, or subsequent versions
** as allowed by the SLA, and You may not copy or use this file in either
** source code or executable form, except in compliance with the terms and
** conditions of the SLA.
**
** All software distributed under the SLA is provided strictly on an
** "AS IS" basis, WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESS OR IMPLIED,
** AND LICENSOR HEREBY DISCLAIMS ALL SUCH WARRANTIES, INCLUDING WITHOUT
** LIMITATION, ANY WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
** PURPOSE, QUIET ENJOYMENT, OR NON-INFRINGEMENT. See the SLA for specific
** language governing rights and limitations under the SLA.
**
** The complete license agreement can be found here:
** http://unifiedautomation.com/License/SLA/2.7/
**
** Project: C++ OPC SDK base module
**
** Portable UaThreeDCartesianCoordinates class.
**
******************************************************************************/
#ifndef UATHREEDCARTESIANCOORDINATES_H
#define UATHREEDCARTESIANCOORDINATES_H

#include <opcua_proxystub.h>

#include "uabase.h"
#include "uaarraytemplates.h"

class UaExtensionObject;
class UaVariant;
class UaDataValue;

class UABASE_EXPORT UaThreeDCartesianCoordinatesPrivate;

/** @ingroup CppBaseLibraryClass
 *  @brief Wrapper class for the UA stack structure OpcUa_ThreeDCartesianCoordinates.
 *
 *  This class encapsulates the native OpcUa_ThreeDCartesianCoordinates structure
 *  and handles memory allocation and cleanup for you.
 *  UaThreeDCartesianCoordinates uses implicit sharing to avoid needless copying and to boost the performance.
 *  Only if you modify a shared ThreeDCartesianCoordinates it creates a copy for that (copy-on-write).
 *  So assigning another UaThreeDCartesianCoordinates or passing it as parameter needs constant time and is nearly as fast as assigning a pointer.
 */
class UABASE_EXPORT UaThreeDCartesianCoordinates
{
    UA_DECLARE_PRIVATE(UaThreeDCartesianCoordinates)
public:
    UaThreeDCartesianCoordinates();
    UaThreeDCartesianCoordinates(const UaThreeDCartesianCoordinates &other);
    UaThreeDCartesianCoordinates(const OpcUa_ThreeDCartesianCoordinates &other);
    UaThreeDCartesianCoordinates(
        OpcUa_Double x,
        OpcUa_Double y,
        OpcUa_Double z
        );
    UaThreeDCartesianCoordinates(const UaExtensionObject &extensionObject);
    UaThreeDCartesianCoordinates(const OpcUa_ExtensionObject &extensionObject);
    UaThreeDCartesianCoordinates(UaExtensionObject &extensionObject, OpcUa_Boolean bDetach);
    UaThreeDCartesianCoordinates(OpcUa_ExtensionObject &extensionObject, OpcUa_Boolean bDetach);
    ~UaThreeDCartesianCoordinates();

    void clear();

    bool operator==(const UaThreeDCartesianCoordinates &other) const;
    bool operator!=(const UaThreeDCartesianCoordinates &other) const;

    UaThreeDCartesianCoordinates& operator=(const UaThreeDCartesianCoordinates &other);

    OpcUa_ThreeDCartesianCoordinates* copy() const;
    void copyTo(OpcUa_ThreeDCartesianCoordinates *pDst) const;

    static OpcUa_ThreeDCartesianCoordinates* clone(const OpcUa_ThreeDCartesianCoordinates& source);
    static void cloneTo(const OpcUa_ThreeDCartesianCoordinates& source, OpcUa_ThreeDCartesianCoordinates& copy);

    void attach(OpcUa_ThreeDCartesianCoordinates *pValue);
    OpcUa_ThreeDCartesianCoordinates* detach(OpcUa_ThreeDCartesianCoordinates* pDst);

    void toVariant(UaVariant &variant) const;
    void toVariant(OpcUa_Variant &variant) const;
    void toVariant(UaVariant &variant, OpcUa_Boolean bDetach);
    void toVariant(OpcUa_Variant &variant, OpcUa_Boolean bDetach);

    void toDataValue(UaDataValue &dataValue, OpcUa_Boolean updateTimeStamps) const;
    void toDataValue(OpcUa_DataValue &dataValue, OpcUa_Boolean updateTimeStamps) const;
    void toDataValue(UaDataValue &dataValue, OpcUa_Boolean bDetach, OpcUa_Boolean updateTimeStamps);
    void toDataValue(OpcUa_DataValue &dataValue, OpcUa_Boolean bDetach, OpcUa_Boolean updateTimeStamps);

    void toExtensionObject(UaExtensionObject &extensionObject) const;
    void toExtensionObject(OpcUa_ExtensionObject &extensionObject) const;
    void toExtensionObject(UaExtensionObject &extensionObject, OpcUa_Boolean bDetach);
    void toExtensionObject(OpcUa_ExtensionObject &extensionObject, OpcUa_Boolean bDetach);

    OpcUa_StatusCode setThreeDCartesianCoordinates(const UaExtensionObject &extensionObject);
    OpcUa_StatusCode setThreeDCartesianCoordinates(const OpcUa_ExtensionObject &extensionObject);
    OpcUa_StatusCode setThreeDCartesianCoordinates(UaExtensionObject &extensionObject, OpcUa_Boolean bDetach);
    OpcUa_StatusCode setThreeDCartesianCoordinates(OpcUa_ExtensionObject &extensionObject, OpcUa_Boolean bDetach);

    void setThreeDCartesianCoordinates(
        OpcUa_Double x,
        OpcUa_Double y,
        OpcUa_Double z
        );

    OpcUa_Double getX() const;
    OpcUa_Double getY() const;
    OpcUa_Double getZ() const;

    void setX(OpcUa_Double x);
    void setY(OpcUa_Double y);
    void setZ(OpcUa_Double z);
};

/** @ingroup CppBaseLibraryClass
 *  @brief Array class for the UA stack structure OpcUa_ThreeDCartesianCoordinates.
 *
 *  This class encapsulates an array of the native OpcUa_ThreeDCartesianCoordinates structure
 *  and handles memory allocation and cleanup for you.
 *  @see UaThreeDCartesianCoordinates for information about the encapsulated structure.
 */
class UABASE_EXPORT UaThreeDCartesianCoordinatess
{
public:
    UaThreeDCartesianCoordinatess();
    UaThreeDCartesianCoordinatess(const UaThreeDCartesianCoordinatess &other);
    UaThreeDCartesianCoordinatess(OpcUa_Int32 length, OpcUa_ThreeDCartesianCoordinates* data);
    virtual ~UaThreeDCartesianCoordinatess();

    UaThreeDCartesianCoordinatess& operator=(const UaThreeDCartesianCoordinatess &other);
    const OpcUa_ThreeDCartesianCoordinates& operator[](OpcUa_UInt32 index) const;
    OpcUa_ThreeDCartesianCoordinates& operator[](OpcUa_UInt32 index);

    bool operator==(const UaThreeDCartesianCoordinatess &other) const;
    bool operator!=(const UaThreeDCartesianCoordinatess &other) const;

    void attach(OpcUa_UInt32 length, OpcUa_ThreeDCartesianCoordinates* data);
    void attach(OpcUa_Int32 length, OpcUa_ThreeDCartesianCoordinates* data);
    OpcUa_ThreeDCartesianCoordinates* detach();

    void create(OpcUa_UInt32 length);
    void resize(OpcUa_UInt32 length);
    void clear();

    inline OpcUa_UInt32 length() const {return m_noOfElements;}
    inline const OpcUa_ThreeDCartesianCoordinates* rawData() const {return m_data;}
    inline OpcUa_ThreeDCartesianCoordinates* rawData() {return m_data;}

    void toVariant(UaVariant &variant) const;
    void toVariant(OpcUa_Variant &variant) const;
    void toVariant(UaVariant &variant, OpcUa_Boolean bDetach);
    void toVariant(OpcUa_Variant &variant, OpcUa_Boolean bDetach);

    void toDataValue(UaDataValue &dataValue, OpcUa_Boolean updateTimeStamps) const;
    void toDataValue(OpcUa_DataValue &dataValue, OpcUa_Boolean updateTimeStamps) const;
    void toDataValue(UaDataValue &dataValue, OpcUa_Boolean bDetach, OpcUa_Boolean updateTimeStamps);
    void toDataValue(OpcUa_DataValue &dataValue, OpcUa_Boolean bDetach, OpcUa_Boolean updateTimeStamps);

    OpcUa_StatusCode setThreeDCartesianCoordinatess(const UaVariant &variant);
    OpcUa_StatusCode setThreeDCartesianCoordinatess(const OpcUa_Variant &variant);
    OpcUa_StatusCode setThreeDCartesianCoordinatess(UaVariant &variant, OpcUa_Boolean bDetach);
    OpcUa_StatusCode setThreeDCartesianCoordinatess(OpcUa_Variant &variant, OpcUa_Boolean bDetach);
    OpcUa_StatusCode setThreeDCartesianCoordinatess(OpcUa_Int32 length, OpcUa_ThreeDCartesianCoordinates* data);

private:
    OpcUa_UInt32 m_noOfElements;
    OpcUa_ThreeDCartesianCoordinates* m_data;
};

#endif // UATHREEDCARTESIANCOORDINATES_H

