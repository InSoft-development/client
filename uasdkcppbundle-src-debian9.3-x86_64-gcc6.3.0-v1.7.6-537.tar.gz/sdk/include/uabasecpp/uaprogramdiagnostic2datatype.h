/******************************************************************************
** uaprogramdiagnostic2datatype.h
**
** Copyright (c) 2006-2022 Unified Automation GmbH. All rights reserved.
**
** Software License Agreement ("SLA") Version 2.7
**
** Unless explicitly acquired and licensed from Licensor under another
** license, the contents of this file are subject to the Software License
** Agreement ("SLA") Version 2.7, or subsequent versions
** as allowed by the SLA, and You may not copy or use this file in either
** source code or executable form, except in compliance with the terms and
** conditions of the SLA.
**
** All software distributed under the SLA is provided strictly on an
** "AS IS" basis, WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESS OR IMPLIED,
** AND LICENSOR HEREBY DISCLAIMS ALL SUCH WARRANTIES, INCLUDING WITHOUT
** LIMITATION, ANY WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
** PURPOSE, QUIET ENJOYMENT, OR NON-INFRINGEMENT. See the SLA for specific
** language governing rights and limitations under the SLA.
**
** The complete license agreement can be found here:
** http://unifiedautomation.com/License/SLA/2.7/
**
** Project: C++ OPC SDK base module
**
** Portable UaProgramDiagnostic2DataType class.
**
******************************************************************************/
#ifndef UAPROGRAMDIAGNOSTIC2DATATYPE_H
#define UAPROGRAMDIAGNOSTIC2DATATYPE_H

#include <opcua_proxystub.h>

#include "uabase.h"
#include "uaargument.h"
#include "uadatetime.h"
#include "uanodeid.h"
#include "statuscode.h"
#include "uastring.h"
#include "uavariant.h"
#include "uaarraytemplates.h"

class UaExtensionObject;
class UaDataValue;

class UABASE_EXPORT UaProgramDiagnostic2DataTypePrivate;

/** @ingroup CppBaseLibraryClass
 *  @brief Wrapper class for the UA stack structure OpcUa_ProgramDiagnostic2DataType.
 *
 *  This class encapsulates the native OpcUa_ProgramDiagnostic2DataType structure
 *  and handles memory allocation and cleanup for you.
 *  UaProgramDiagnostic2DataType uses implicit sharing to avoid needless copying and to boost the performance.
 *  Only if you modify a shared ProgramDiagnostic2DataType it creates a copy for that (copy-on-write).
 *  So assigning another UaProgramDiagnostic2DataType or passing it as parameter needs constant time and is nearly as fast as assigning a pointer.
 */
class UABASE_EXPORT UaProgramDiagnostic2DataType
{
    UA_DECLARE_PRIVATE(UaProgramDiagnostic2DataType)
public:
    UaProgramDiagnostic2DataType();
    UaProgramDiagnostic2DataType(const UaProgramDiagnostic2DataType &other);
    UaProgramDiagnostic2DataType(const OpcUa_ProgramDiagnostic2DataType &other);
    UaProgramDiagnostic2DataType(
        const UaNodeId& createSessionId,
        const UaString& createClientName,
        const UaDateTime& invocationCreationTime,
        const UaDateTime& lastTransitionTime,
        const UaString& lastMethodCall,
        const UaNodeId& lastMethodSessionId,
        const UaArguments &lastMethodInputArguments,
        const UaArguments &lastMethodOutputArguments,
        const UaVariantArray &lastMethodInputValues,
        const UaVariantArray &lastMethodOutputValues,
        const UaDateTime& lastMethodCallTime,
        const UaStatus& lastMethodReturnStatus
        );
    UaProgramDiagnostic2DataType(const UaExtensionObject &extensionObject);
    UaProgramDiagnostic2DataType(const OpcUa_ExtensionObject &extensionObject);
    UaProgramDiagnostic2DataType(UaExtensionObject &extensionObject, OpcUa_Boolean bDetach);
    UaProgramDiagnostic2DataType(OpcUa_ExtensionObject &extensionObject, OpcUa_Boolean bDetach);
    ~UaProgramDiagnostic2DataType();

    void clear();

    bool operator==(const UaProgramDiagnostic2DataType &other) const;
    bool operator!=(const UaProgramDiagnostic2DataType &other) const;

    UaProgramDiagnostic2DataType& operator=(const UaProgramDiagnostic2DataType &other);

    OpcUa_ProgramDiagnostic2DataType* copy() const;
    void copyTo(OpcUa_ProgramDiagnostic2DataType *pDst) const;

    static OpcUa_ProgramDiagnostic2DataType* clone(const OpcUa_ProgramDiagnostic2DataType& source);
    static void cloneTo(const OpcUa_ProgramDiagnostic2DataType& source, OpcUa_ProgramDiagnostic2DataType& copy);

    void attach(OpcUa_ProgramDiagnostic2DataType *pValue);
    OpcUa_ProgramDiagnostic2DataType* detach(OpcUa_ProgramDiagnostic2DataType* pDst);

    void toVariant(UaVariant &variant) const;
    void toVariant(OpcUa_Variant &variant) const;
    void toVariant(UaVariant &variant, OpcUa_Boolean bDetach);
    void toVariant(OpcUa_Variant &variant, OpcUa_Boolean bDetach);

    void toDataValue(UaDataValue &dataValue, OpcUa_Boolean updateTimeStamps) const;
    void toDataValue(OpcUa_DataValue &dataValue, OpcUa_Boolean updateTimeStamps) const;
    void toDataValue(UaDataValue &dataValue, OpcUa_Boolean bDetach, OpcUa_Boolean updateTimeStamps);
    void toDataValue(OpcUa_DataValue &dataValue, OpcUa_Boolean bDetach, OpcUa_Boolean updateTimeStamps);

    void toExtensionObject(UaExtensionObject &extensionObject) const;
    void toExtensionObject(OpcUa_ExtensionObject &extensionObject) const;
    void toExtensionObject(UaExtensionObject &extensionObject, OpcUa_Boolean bDetach);
    void toExtensionObject(OpcUa_ExtensionObject &extensionObject, OpcUa_Boolean bDetach);

    OpcUa_StatusCode setProgramDiagnostic2DataType(const UaExtensionObject &extensionObject);
    OpcUa_StatusCode setProgramDiagnostic2DataType(const OpcUa_ExtensionObject &extensionObject);
    OpcUa_StatusCode setProgramDiagnostic2DataType(UaExtensionObject &extensionObject, OpcUa_Boolean bDetach);
    OpcUa_StatusCode setProgramDiagnostic2DataType(OpcUa_ExtensionObject &extensionObject, OpcUa_Boolean bDetach);

    void setProgramDiagnostic2DataType(
        const UaNodeId& createSessionId,
        const UaString& createClientName,
        const UaDateTime& invocationCreationTime,
        const UaDateTime& lastTransitionTime,
        const UaString& lastMethodCall,
        const UaNodeId& lastMethodSessionId,
        const UaArguments &lastMethodInputArguments,
        const UaArguments &lastMethodOutputArguments,
        const UaVariantArray &lastMethodInputValues,
        const UaVariantArray &lastMethodOutputValues,
        const UaDateTime& lastMethodCallTime,
        const UaStatus& lastMethodReturnStatus
        );

    UaNodeId getCreateSessionId() const;
    UaString getCreateClientName() const;
    UaDateTime getInvocationCreationTime() const;
    UaDateTime getLastTransitionTime() const;
    UaString getLastMethodCall() const;
    UaNodeId getLastMethodSessionId() const;
    void getLastMethodInputArguments(UaArguments& lastMethodInputArguments) const;
    void getLastMethodOutputArguments(UaArguments& lastMethodOutputArguments) const;
    void getLastMethodInputValues(UaVariantArray& lastMethodInputValues) const;
    void getLastMethodOutputValues(UaVariantArray& lastMethodOutputValues) const;
    UaDateTime getLastMethodCallTime() const;
    UaStatus getLastMethodReturnStatus() const;

    void setCreateSessionId(const UaNodeId& createSessionId);
    void setCreateClientName(const UaString& createClientName);
    void setInvocationCreationTime(const UaDateTime& invocationCreationTime);
    void setLastTransitionTime(const UaDateTime& lastTransitionTime);
    void setLastMethodCall(const UaString& lastMethodCall);
    void setLastMethodSessionId(const UaNodeId& lastMethodSessionId);
    void setLastMethodInputArguments(const UaArguments &lastMethodInputArguments);
    void setLastMethodOutputArguments(const UaArguments &lastMethodOutputArguments);
    void setLastMethodInputValues(const UaVariantArray &lastMethodInputValues);
    void setLastMethodOutputValues(const UaVariantArray &lastMethodOutputValues);
    void setLastMethodCallTime(const UaDateTime& lastMethodCallTime);
    void setLastMethodReturnStatus(const UaStatus& lastMethodReturnStatus);
};

/** @ingroup CppBaseLibraryClass
 *  @brief Array class for the UA stack structure OpcUa_ProgramDiagnostic2DataType.
 *
 *  This class encapsulates an array of the native OpcUa_ProgramDiagnostic2DataType structure
 *  and handles memory allocation and cleanup for you.
 *  @see UaProgramDiagnostic2DataType for information about the encapsulated structure.
 */
class UABASE_EXPORT UaProgramDiagnostic2DataTypes
{
public:
    UaProgramDiagnostic2DataTypes();
    UaProgramDiagnostic2DataTypes(const UaProgramDiagnostic2DataTypes &other);
    UaProgramDiagnostic2DataTypes(OpcUa_Int32 length, OpcUa_ProgramDiagnostic2DataType* data);
    virtual ~UaProgramDiagnostic2DataTypes();

    UaProgramDiagnostic2DataTypes& operator=(const UaProgramDiagnostic2DataTypes &other);
    const OpcUa_ProgramDiagnostic2DataType& operator[](OpcUa_UInt32 index) const;
    OpcUa_ProgramDiagnostic2DataType& operator[](OpcUa_UInt32 index);

    bool operator==(const UaProgramDiagnostic2DataTypes &other) const;
    bool operator!=(const UaProgramDiagnostic2DataTypes &other) const;

    void attach(OpcUa_UInt32 length, OpcUa_ProgramDiagnostic2DataType* data);
    void attach(OpcUa_Int32 length, OpcUa_ProgramDiagnostic2DataType* data);
    OpcUa_ProgramDiagnostic2DataType* detach();

    void create(OpcUa_UInt32 length);
    void resize(OpcUa_UInt32 length);
    void clear();

    inline OpcUa_UInt32 length() const {return m_noOfElements;}
    inline const OpcUa_ProgramDiagnostic2DataType* rawData() const {return m_data;}
    inline OpcUa_ProgramDiagnostic2DataType* rawData() {return m_data;}

    void toVariant(UaVariant &variant) const;
    void toVariant(OpcUa_Variant &variant) const;
    void toVariant(UaVariant &variant, OpcUa_Boolean bDetach);
    void toVariant(OpcUa_Variant &variant, OpcUa_Boolean bDetach);

    void toDataValue(UaDataValue &dataValue, OpcUa_Boolean updateTimeStamps) const;
    void toDataValue(OpcUa_DataValue &dataValue, OpcUa_Boolean updateTimeStamps) const;
    void toDataValue(UaDataValue &dataValue, OpcUa_Boolean bDetach, OpcUa_Boolean updateTimeStamps);
    void toDataValue(OpcUa_DataValue &dataValue, OpcUa_Boolean bDetach, OpcUa_Boolean updateTimeStamps);

    OpcUa_StatusCode setProgramDiagnostic2DataTypes(const UaVariant &variant);
    OpcUa_StatusCode setProgramDiagnostic2DataTypes(const OpcUa_Variant &variant);
    OpcUa_StatusCode setProgramDiagnostic2DataTypes(UaVariant &variant, OpcUa_Boolean bDetach);
    OpcUa_StatusCode setProgramDiagnostic2DataTypes(OpcUa_Variant &variant, OpcUa_Boolean bDetach);
    OpcUa_StatusCode setProgramDiagnostic2DataTypes(OpcUa_Int32 length, OpcUa_ProgramDiagnostic2DataType* data);

private:
    OpcUa_UInt32 m_noOfElements;
    OpcUa_ProgramDiagnostic2DataType* m_data;
};

#endif // UAPROGRAMDIAGNOSTIC2DATATYPE_H

