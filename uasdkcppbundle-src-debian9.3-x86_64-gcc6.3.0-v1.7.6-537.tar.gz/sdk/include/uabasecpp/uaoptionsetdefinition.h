/******************************************************************************
** uaoptionsetdefinition.h
**
** Copyright (c) 2006-2022 Unified Automation GmbH. All rights reserved.
**
** Software License Agreement ("SLA") Version 2.7
**
** Unless explicitly acquired and licensed from Licensor under another
** license, the contents of this file are subject to the Software License
** Agreement ("SLA") Version 2.7, or subsequent versions
** as allowed by the SLA, and You may not copy or use this file in either
** source code or executable form, except in compliance with the terms and
** conditions of the SLA.
**
** All software distributed under the SLA is provided strictly on an
** "AS IS" basis, WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESS OR IMPLIED,
** AND LICENSOR HEREBY DISCLAIMS ALL SUCH WARRANTIES, INCLUDING WITHOUT
** LIMITATION, ANY WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
** PURPOSE, QUIET ENJOYMENT, OR NON-INFRINGEMENT. See the SLA for specific
** language governing rights and limitations under the SLA.
**
** The complete license agreement can be found here:
** http://unifiedautomation.com/License/SLA/2.7/
**
** Project: C++ OPC SDK base module
**
******************************************************************************/
#ifndef UAOPTIONSETDEFINITION_H
#define UAOPTIONSETDEFINITION_H

#include "uaabstractdefinition.h"
#include "uaenumdefinitiondatatype.h"
#include "uaenumvalue.h"

class UaLocalizedText;
class UaLocalizedTextArray;

/** Manages the description for an OptionSet DataType.
 *
 * OptionSets are bit masks where the data type provides names for all valid
 * bits in the bit mask. An OptionSet is either a sub-type of one of the UInteger
 * built-in types (Byte, UInt16, UInt32, UInt64) or a sub-type of the OptionSet
 * structure. The option set based on the structure allows an unlimited size of the
 * bit mask but has also a second bit mask that indicates the bits that are set (valid)
 * in a OptionSet value.
 *
 * The actually used base type is indicated with BaseType (baseType(), setBaseType()).
 * The BaseType option BaseType_OptionSet provides valid bits. The availablity of valid bits
 * can be checked with hasValidBits().
 *
 * The bits are described with the class UaEnumValue. A UaEnumValue provides the name
 * and the bit number of a bit.
 *
 * This class can be used to add an OptionSet DataType on server side as well as a description
 * of available DataTypes in a server on client side.
 *
 */
class UABASE_EXPORT UaOptionSetDefinition : public UaAbstractDefinition
{
public:
    UaOptionSetDefinition();
    UaOptionSetDefinition(const UaOptionSetDefinition &other);
    UaOptionSetDefinition(const OpcUa_EnumDefinition *other, const UaNodeId &typeId);

    enum BaseType
    {
        BaseType_Byte,
        BaseType_UInt16,
        BaseType_UInt32,
        BaseType_UInt64,
        BaseType_OptionSet
    };

    UaOptionSetDefinition& operator=(const UaOptionSetDefinition &other);

    bool operator==(const UaOptionSetDefinition &other) const;
    bool operator!=(const UaOptionSetDefinition &other) const;

    // UaAbstractDefinition interface
    virtual UaDataTypeDictionary::DefinitionType definitionType() const { return UaDataTypeDictionary::DefinitionType_OptionSet; }
    virtual int childrenCount() const;
    virtual void clear();
    virtual bool isNull() const;

    BaseType baseType() const;
    void setBaseType(BaseType baseType);
    UaEnumValue child(int i) const;
    UaLocalizedTextArray children() const;
    void addChild(const UaEnumValue &newChild);
    void addChild(const UaString &sName, int value);
    void addChild(const UaString &sName, int value, const UaLocalizedText &sDocumentation);
    void addChild(const UaLocalizedText &newChild);

    bool hasValidBits() const;

    void setBinaryEncodingId(const UaNodeId &nodeId);
    UaNodeId binaryEncodingId() const;
    void setXmlEncodingId(const UaNodeId &nodeId);
    UaNodeId xmlEncodingId() const;

    UaStructureDefinition structureDefinition() const;

    UaOptionSetDefinition mapNamespaces(NamespaceMappingInterface *pMapper) const;

    UaEnumDefinitionDataType getEnumDefinitionDataType() const;

protected:
    virtual UaAbstractDefinitionPrivate* copyPrivate();
};

#endif
