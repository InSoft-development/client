/******************************************************************************
** uathreedorientation.h
**
** Copyright (c) 2006-2022 Unified Automation GmbH. All rights reserved.
**
** Software License Agreement ("SLA") Version 2.7
**
** Unless explicitly acquired and licensed from Licensor under another
** license, the contents of this file are subject to the Software License
** Agreement ("SLA") Version 2.7, or subsequent versions
** as allowed by the SLA, and You may not copy or use this file in either
** source code or executable form, except in compliance with the terms and
** conditions of the SLA.
**
** All software distributed under the SLA is provided strictly on an
** "AS IS" basis, WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESS OR IMPLIED,
** AND LICENSOR HEREBY DISCLAIMS ALL SUCH WARRANTIES, INCLUDING WITHOUT
** LIMITATION, ANY WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
** PURPOSE, QUIET ENJOYMENT, OR NON-INFRINGEMENT. See the SLA for specific
** language governing rights and limitations under the SLA.
**
** The complete license agreement can be found here:
** http://unifiedautomation.com/License/SLA/2.7/
**
** Project: C++ OPC SDK base module
**
** Portable UaThreeDOrientation class.
**
******************************************************************************/
#ifndef UATHREEDORIENTATION_H
#define UATHREEDORIENTATION_H

#include <opcua_proxystub.h>

#include "uabase.h"
#include "uaarraytemplates.h"

class UaExtensionObject;
class UaVariant;
class UaDataValue;

class UABASE_EXPORT UaThreeDOrientationPrivate;

/** @ingroup CppBaseLibraryClass
 *  @brief Wrapper class for the UA stack structure OpcUa_ThreeDOrientation.
 *
 *  This class encapsulates the native OpcUa_ThreeDOrientation structure
 *  and handles memory allocation and cleanup for you.
 *  UaThreeDOrientation uses implicit sharing to avoid needless copying and to boost the performance.
 *  Only if you modify a shared ThreeDOrientation it creates a copy for that (copy-on-write).
 *  So assigning another UaThreeDOrientation or passing it as parameter needs constant time and is nearly as fast as assigning a pointer.
 */
class UABASE_EXPORT UaThreeDOrientation
{
    UA_DECLARE_PRIVATE(UaThreeDOrientation)
public:
    UaThreeDOrientation();
    UaThreeDOrientation(const UaThreeDOrientation &other);
    UaThreeDOrientation(const OpcUa_ThreeDOrientation &other);
    UaThreeDOrientation(
        OpcUa_Double a,
        OpcUa_Double b,
        OpcUa_Double c
        );
    UaThreeDOrientation(const UaExtensionObject &extensionObject);
    UaThreeDOrientation(const OpcUa_ExtensionObject &extensionObject);
    UaThreeDOrientation(UaExtensionObject &extensionObject, OpcUa_Boolean bDetach);
    UaThreeDOrientation(OpcUa_ExtensionObject &extensionObject, OpcUa_Boolean bDetach);
    ~UaThreeDOrientation();

    void clear();

    bool operator==(const UaThreeDOrientation &other) const;
    bool operator!=(const UaThreeDOrientation &other) const;

    UaThreeDOrientation& operator=(const UaThreeDOrientation &other);

    OpcUa_ThreeDOrientation* copy() const;
    void copyTo(OpcUa_ThreeDOrientation *pDst) const;

    static OpcUa_ThreeDOrientation* clone(const OpcUa_ThreeDOrientation& source);
    static void cloneTo(const OpcUa_ThreeDOrientation& source, OpcUa_ThreeDOrientation& copy);

    void attach(OpcUa_ThreeDOrientation *pValue);
    OpcUa_ThreeDOrientation* detach(OpcUa_ThreeDOrientation* pDst);

    void toVariant(UaVariant &variant) const;
    void toVariant(OpcUa_Variant &variant) const;
    void toVariant(UaVariant &variant, OpcUa_Boolean bDetach);
    void toVariant(OpcUa_Variant &variant, OpcUa_Boolean bDetach);

    void toDataValue(UaDataValue &dataValue, OpcUa_Boolean updateTimeStamps) const;
    void toDataValue(OpcUa_DataValue &dataValue, OpcUa_Boolean updateTimeStamps) const;
    void toDataValue(UaDataValue &dataValue, OpcUa_Boolean bDetach, OpcUa_Boolean updateTimeStamps);
    void toDataValue(OpcUa_DataValue &dataValue, OpcUa_Boolean bDetach, OpcUa_Boolean updateTimeStamps);

    void toExtensionObject(UaExtensionObject &extensionObject) const;
    void toExtensionObject(OpcUa_ExtensionObject &extensionObject) const;
    void toExtensionObject(UaExtensionObject &extensionObject, OpcUa_Boolean bDetach);
    void toExtensionObject(OpcUa_ExtensionObject &extensionObject, OpcUa_Boolean bDetach);

    OpcUa_StatusCode setThreeDOrientation(const UaExtensionObject &extensionObject);
    OpcUa_StatusCode setThreeDOrientation(const OpcUa_ExtensionObject &extensionObject);
    OpcUa_StatusCode setThreeDOrientation(UaExtensionObject &extensionObject, OpcUa_Boolean bDetach);
    OpcUa_StatusCode setThreeDOrientation(OpcUa_ExtensionObject &extensionObject, OpcUa_Boolean bDetach);

    void setThreeDOrientation(
        OpcUa_Double a,
        OpcUa_Double b,
        OpcUa_Double c
        );

    OpcUa_Double getA() const;
    OpcUa_Double getB() const;
    OpcUa_Double getC() const;

    void setA(OpcUa_Double a);
    void setB(OpcUa_Double b);
    void setC(OpcUa_Double c);
};

/** @ingroup CppBaseLibraryClass
 *  @brief Array class for the UA stack structure OpcUa_ThreeDOrientation.
 *
 *  This class encapsulates an array of the native OpcUa_ThreeDOrientation structure
 *  and handles memory allocation and cleanup for you.
 *  @see UaThreeDOrientation for information about the encapsulated structure.
 */
class UABASE_EXPORT UaThreeDOrientations
{
public:
    UaThreeDOrientations();
    UaThreeDOrientations(const UaThreeDOrientations &other);
    UaThreeDOrientations(OpcUa_Int32 length, OpcUa_ThreeDOrientation* data);
    virtual ~UaThreeDOrientations();

    UaThreeDOrientations& operator=(const UaThreeDOrientations &other);
    const OpcUa_ThreeDOrientation& operator[](OpcUa_UInt32 index) const;
    OpcUa_ThreeDOrientation& operator[](OpcUa_UInt32 index);

    bool operator==(const UaThreeDOrientations &other) const;
    bool operator!=(const UaThreeDOrientations &other) const;

    void attach(OpcUa_UInt32 length, OpcUa_ThreeDOrientation* data);
    void attach(OpcUa_Int32 length, OpcUa_ThreeDOrientation* data);
    OpcUa_ThreeDOrientation* detach();

    void create(OpcUa_UInt32 length);
    void resize(OpcUa_UInt32 length);
    void clear();

    inline OpcUa_UInt32 length() const {return m_noOfElements;}
    inline const OpcUa_ThreeDOrientation* rawData() const {return m_data;}
    inline OpcUa_ThreeDOrientation* rawData() {return m_data;}

    void toVariant(UaVariant &variant) const;
    void toVariant(OpcUa_Variant &variant) const;
    void toVariant(UaVariant &variant, OpcUa_Boolean bDetach);
    void toVariant(OpcUa_Variant &variant, OpcUa_Boolean bDetach);

    void toDataValue(UaDataValue &dataValue, OpcUa_Boolean updateTimeStamps) const;
    void toDataValue(OpcUa_DataValue &dataValue, OpcUa_Boolean updateTimeStamps) const;
    void toDataValue(UaDataValue &dataValue, OpcUa_Boolean bDetach, OpcUa_Boolean updateTimeStamps);
    void toDataValue(OpcUa_DataValue &dataValue, OpcUa_Boolean bDetach, OpcUa_Boolean updateTimeStamps);

    OpcUa_StatusCode setThreeDOrientations(const UaVariant &variant);
    OpcUa_StatusCode setThreeDOrientations(const OpcUa_Variant &variant);
    OpcUa_StatusCode setThreeDOrientations(UaVariant &variant, OpcUa_Boolean bDetach);
    OpcUa_StatusCode setThreeDOrientations(OpcUa_Variant &variant, OpcUa_Boolean bDetach);
    OpcUa_StatusCode setThreeDOrientations(OpcUa_Int32 length, OpcUa_ThreeDOrientation* data);

private:
    OpcUa_UInt32 m_noOfElements;
    OpcUa_ThreeDOrientation* m_data;
};

#endif // UATHREEDORIENTATION_H

