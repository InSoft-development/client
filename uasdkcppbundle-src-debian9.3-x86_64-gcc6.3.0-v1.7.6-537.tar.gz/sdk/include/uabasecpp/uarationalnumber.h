/******************************************************************************
** uarationalnumber.h
**
** Copyright (c) 2006-2022 Unified Automation GmbH. All rights reserved.
**
** Software License Agreement ("SLA") Version 2.7
**
** Unless explicitly acquired and licensed from Licensor under another
** license, the contents of this file are subject to the Software License
** Agreement ("SLA") Version 2.7, or subsequent versions
** as allowed by the SLA, and You may not copy or use this file in either
** source code or executable form, except in compliance with the terms and
** conditions of the SLA.
**
** All software distributed under the SLA is provided strictly on an
** "AS IS" basis, WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESS OR IMPLIED,
** AND LICENSOR HEREBY DISCLAIMS ALL SUCH WARRANTIES, INCLUDING WITHOUT
** LIMITATION, ANY WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
** PURPOSE, QUIET ENJOYMENT, OR NON-INFRINGEMENT. See the SLA for specific
** language governing rights and limitations under the SLA.
**
** The complete license agreement can be found here:
** http://unifiedautomation.com/License/SLA/2.7/
**
** Project: C++ OPC SDK base module
**
** Portable UaRationalNumber class.
**
******************************************************************************/
#ifndef UARATIONALNUMBER_H
#define UARATIONALNUMBER_H

#include <opcua_proxystub.h>

#include "uabase.h"
#include "uaarraytemplates.h"

class UaExtensionObject;
class UaVariant;
class UaDataValue;

class UABASE_EXPORT UaRationalNumberPrivate;

/** @ingroup CppBaseLibraryClass
 *  @brief Wrapper class for the UA stack structure OpcUa_RationalNumber.
 *
 *  This class encapsulates the native OpcUa_RationalNumber structure
 *  and handles memory allocation and cleanup for you.
 *  UaRationalNumber uses implicit sharing to avoid needless copying and to boost the performance.
 *  Only if you modify a shared RationalNumber it creates a copy for that (copy-on-write).
 *  So assigning another UaRationalNumber or passing it as parameter needs constant time and is nearly as fast as assigning a pointer.
 */
class UABASE_EXPORT UaRationalNumber
{
    UA_DECLARE_PRIVATE(UaRationalNumber)
public:
    UaRationalNumber();
    UaRationalNumber(const UaRationalNumber &other);
    UaRationalNumber(const OpcUa_RationalNumber &other);
    UaRationalNumber(
        OpcUa_Int32 numerator,
        OpcUa_UInt32 denominator
        );
    UaRationalNumber(const UaExtensionObject &extensionObject);
    UaRationalNumber(const OpcUa_ExtensionObject &extensionObject);
    UaRationalNumber(UaExtensionObject &extensionObject, OpcUa_Boolean bDetach);
    UaRationalNumber(OpcUa_ExtensionObject &extensionObject, OpcUa_Boolean bDetach);
    ~UaRationalNumber();

    void clear();

    bool operator==(const UaRationalNumber &other) const;
    bool operator!=(const UaRationalNumber &other) const;

    UaRationalNumber& operator=(const UaRationalNumber &other);

    OpcUa_RationalNumber* copy() const;
    void copyTo(OpcUa_RationalNumber *pDst) const;

    static OpcUa_RationalNumber* clone(const OpcUa_RationalNumber& source);
    static void cloneTo(const OpcUa_RationalNumber& source, OpcUa_RationalNumber& copy);

    void attach(OpcUa_RationalNumber *pValue);
    OpcUa_RationalNumber* detach(OpcUa_RationalNumber* pDst);

    void toVariant(UaVariant &variant) const;
    void toVariant(OpcUa_Variant &variant) const;
    void toVariant(UaVariant &variant, OpcUa_Boolean bDetach);
    void toVariant(OpcUa_Variant &variant, OpcUa_Boolean bDetach);

    void toDataValue(UaDataValue &dataValue, OpcUa_Boolean updateTimeStamps) const;
    void toDataValue(OpcUa_DataValue &dataValue, OpcUa_Boolean updateTimeStamps) const;
    void toDataValue(UaDataValue &dataValue, OpcUa_Boolean bDetach, OpcUa_Boolean updateTimeStamps);
    void toDataValue(OpcUa_DataValue &dataValue, OpcUa_Boolean bDetach, OpcUa_Boolean updateTimeStamps);

    void toExtensionObject(UaExtensionObject &extensionObject) const;
    void toExtensionObject(OpcUa_ExtensionObject &extensionObject) const;
    void toExtensionObject(UaExtensionObject &extensionObject, OpcUa_Boolean bDetach);
    void toExtensionObject(OpcUa_ExtensionObject &extensionObject, OpcUa_Boolean bDetach);

    OpcUa_StatusCode setRationalNumber(const UaExtensionObject &extensionObject);
    OpcUa_StatusCode setRationalNumber(const OpcUa_ExtensionObject &extensionObject);
    OpcUa_StatusCode setRationalNumber(UaExtensionObject &extensionObject, OpcUa_Boolean bDetach);
    OpcUa_StatusCode setRationalNumber(OpcUa_ExtensionObject &extensionObject, OpcUa_Boolean bDetach);

    void setRationalNumber(
        OpcUa_Int32 numerator,
        OpcUa_UInt32 denominator
        );

    OpcUa_Int32 getNumerator() const;
    OpcUa_UInt32 getDenominator() const;

    void setNumerator(OpcUa_Int32 numerator);
    void setDenominator(OpcUa_UInt32 denominator);
};

/** @ingroup CppBaseLibraryClass
 *  @brief Array class for the UA stack structure OpcUa_RationalNumber.
 *
 *  This class encapsulates an array of the native OpcUa_RationalNumber structure
 *  and handles memory allocation and cleanup for you.
 *  @see UaRationalNumber for information about the encapsulated structure.
 */
class UABASE_EXPORT UaRationalNumbers
{
public:
    UaRationalNumbers();
    UaRationalNumbers(const UaRationalNumbers &other);
    UaRationalNumbers(OpcUa_Int32 length, OpcUa_RationalNumber* data);
    virtual ~UaRationalNumbers();

    UaRationalNumbers& operator=(const UaRationalNumbers &other);
    const OpcUa_RationalNumber& operator[](OpcUa_UInt32 index) const;
    OpcUa_RationalNumber& operator[](OpcUa_UInt32 index);

    bool operator==(const UaRationalNumbers &other) const;
    bool operator!=(const UaRationalNumbers &other) const;

    void attach(OpcUa_UInt32 length, OpcUa_RationalNumber* data);
    void attach(OpcUa_Int32 length, OpcUa_RationalNumber* data);
    OpcUa_RationalNumber* detach();

    void create(OpcUa_UInt32 length);
    void resize(OpcUa_UInt32 length);
    void clear();

    inline OpcUa_UInt32 length() const {return m_noOfElements;}
    inline const OpcUa_RationalNumber* rawData() const {return m_data;}
    inline OpcUa_RationalNumber* rawData() {return m_data;}

    void toVariant(UaVariant &variant) const;
    void toVariant(OpcUa_Variant &variant) const;
    void toVariant(UaVariant &variant, OpcUa_Boolean bDetach);
    void toVariant(OpcUa_Variant &variant, OpcUa_Boolean bDetach);

    void toDataValue(UaDataValue &dataValue, OpcUa_Boolean updateTimeStamps) const;
    void toDataValue(OpcUa_DataValue &dataValue, OpcUa_Boolean updateTimeStamps) const;
    void toDataValue(UaDataValue &dataValue, OpcUa_Boolean bDetach, OpcUa_Boolean updateTimeStamps);
    void toDataValue(OpcUa_DataValue &dataValue, OpcUa_Boolean bDetach, OpcUa_Boolean updateTimeStamps);

    OpcUa_StatusCode setRationalNumbers(const UaVariant &variant);
    OpcUa_StatusCode setRationalNumbers(const OpcUa_Variant &variant);
    OpcUa_StatusCode setRationalNumbers(UaVariant &variant, OpcUa_Boolean bDetach);
    OpcUa_StatusCode setRationalNumbers(OpcUa_Variant &variant, OpcUa_Boolean bDetach);
    OpcUa_StatusCode setRationalNumbers(OpcUa_Int32 length, OpcUa_RationalNumber* data);

private:
    OpcUa_UInt32 m_noOfElements;
    OpcUa_RationalNumber* m_data;
};

#endif // UARATIONALNUMBER_H

