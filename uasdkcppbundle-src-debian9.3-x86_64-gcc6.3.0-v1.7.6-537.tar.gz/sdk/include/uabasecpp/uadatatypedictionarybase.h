/******************************************************************************
** uadatatypedictionarybase.h
**
** Copyright (c) 2006-2022 Unified Automation GmbH. All rights reserved.
**
** Software License Agreement ("SLA") Version 2.7
**
** Unless explicitly acquired and licensed from Licensor under another
** license, the contents of this file are subject to the Software License
** Agreement ("SLA") Version 2.7, or subsequent versions
** as allowed by the SLA, and You may not copy or use this file in either
** source code or executable form, except in compliance with the terms and
** conditions of the SLA.
**
** All software distributed under the SLA is provided strictly on an
** "AS IS" basis, WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESS OR IMPLIED,
** AND LICENSOR HEREBY DISCLAIMS ALL SUCH WARRANTIES, INCLUDING WITHOUT
** LIMITATION, ANY WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
** PURPOSE, QUIET ENJOYMENT, OR NON-INFRINGEMENT. See the SLA for specific
** language governing rights and limitations under the SLA.
**
** The complete license agreement can be found here:
** http://unifiedautomation.com/License/SLA/2.7/
**
** Project: C++ OPC SDK base module
**
******************************************************************************/
#ifndef UADATATYPEDICTIONARYBASE_H
#define UADATATYPEDICTIONARYBASE_H

#include "uaabstractdefinition.h"
#include "uamutex.h"
#include <map>
#include <list>

/** Base class for managing DataType information for one server.
*
* There are four main groups of OPC UA data types where this class provides the
* necessary information for processing of the data types.
*
* Simple data types are subtypes of built-in data types and are transported
* as the corresponding built-in data type.
*
* Enumerations provide string representations of numeric values but the
* transport of the value is always done with the built-in data type Int32.
*
* OptionSets are bit masks where the data type provides names for all valid
* bits in the bit mask. An OptionSet is either a sub-type of one of the UInteger
* built-in types (Byte, UInt16, UInt32, UInt64) or a sub-type of the OptionSet
* structure.
*
* Structures are composed of an ordered list of fields where every field has a
* data type out or the four groups. Structures are transported in an ExtensionObject
* as byte blob (ByteString) and a type identifier.
*/
class UABASE_EXPORT UaDataTypeDictionaryBase : public UaDataTypeDictionary
{
public:
    UaDataTypeDictionaryBase();
    virtual ~UaDataTypeDictionaryBase();
    void clearDefinitions();

    virtual DefinitionType definitionType(const UaNodeId &dataTypeId);
    virtual UaEnumDefinition enumDefinition(const UaNodeId &dataTypeId);
    virtual UaOptionSetDefinition optionSetDefinition(const UaNodeId &dataTypeId);
    virtual UaStructureDefinition structureDefinition(const UaNodeId &dataTypeId);
    virtual UaSimpleDefinition simpleDefinition(const UaNodeId &dataTypeId);
    int numDefinitions();

    bool addDefinition(UaAbstractDefinition* pNewDefinition, bool overwrite = true);
    bool removeDefinition(const UaNodeId& identifier);

    virtual std::list<UaEnumDefinition> enumDefinitions();
    virtual std::list<UaEnumDefinition> enumDefinitions(OpcUa_UInt16 namespaceIndex);
    virtual std::list<UaOptionSetDefinition> optionSetDefinitions();
    virtual std::list<UaOptionSetDefinition> optionSetDefinitions(OpcUa_UInt16 namespaceIndex);
    virtual std::list<UaStructureDefinition> structureDefinitions();
    virtual std::list<UaStructureDefinition> structureDefinitions(OpcUa_UInt16 namespaceIndex);
    virtual std::list<UaSimpleDefinition> simpleDefinitions();
    virtual std::list<UaSimpleDefinition> simpleDefinitions(OpcUa_UInt16 namespaceIndex);

private:
    UaAbstractDefinition* getDefinition(const UaNodeId &dataTypeId);
private:
    UaMutex m_mutex;
    std::map<UaNodeId, UaAbstractDefinition*> m_mapDataTypeDefinitions;
};

#endif // UADATATYPEDICTIONARYBASE_H
