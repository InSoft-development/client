/******************************************************************************
** uanetworkaddressurldatatype.h
**
** Copyright (c) 2006-2022 Unified Automation GmbH. All rights reserved.
**
** Software License Agreement ("SLA") Version 2.7
**
** Unless explicitly acquired and licensed from Licensor under another
** license, the contents of this file are subject to the Software License
** Agreement ("SLA") Version 2.7, or subsequent versions
** as allowed by the SLA, and You may not copy or use this file in either
** source code or executable form, except in compliance with the terms and
** conditions of the SLA.
**
** All software distributed under the SLA is provided strictly on an
** "AS IS" basis, WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESS OR IMPLIED,
** AND LICENSOR HEREBY DISCLAIMS ALL SUCH WARRANTIES, INCLUDING WITHOUT
** LIMITATION, ANY WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
** PURPOSE, QUIET ENJOYMENT, OR NON-INFRINGEMENT. See the SLA for specific
** language governing rights and limitations under the SLA.
**
** The complete license agreement can be found here:
** http://unifiedautomation.com/License/SLA/2.7/
**
** Project: C++ OPC SDK base module
**
** Portable UaNetworkAddressUrlDataType class.
**
******************************************************************************/
#ifndef UANETWORKADDRESSURLDATATYPE_H
#define UANETWORKADDRESSURLDATATYPE_H

#include <opcua_proxystub.h>

#include "uabase.h"
#include "uastring.h"
#include "uaarraytemplates.h"

class UaExtensionObject;
class UaVariant;
class UaDataValue;

class UABASE_EXPORT UaNetworkAddressUrlDataTypePrivate;

/** @ingroup CppBaseLibraryClass
 *  @brief Wrapper class for the UA stack structure OpcUa_NetworkAddressUrlDataType.
 *
 *  This class encapsulates the native OpcUa_NetworkAddressUrlDataType structure
 *  and handles memory allocation and cleanup for you.
 *  UaNetworkAddressUrlDataType uses implicit sharing to avoid needless copying and to boost the performance.
 *  Only if you modify a shared NetworkAddressUrlDataType it creates a copy for that (copy-on-write).
 *  So assigning another UaNetworkAddressUrlDataType or passing it as parameter needs constant time and is nearly as fast as assigning a pointer.
 */
class UABASE_EXPORT UaNetworkAddressUrlDataType
{
    UA_DECLARE_PRIVATE(UaNetworkAddressUrlDataType)
public:
    UaNetworkAddressUrlDataType();
    UaNetworkAddressUrlDataType(const UaNetworkAddressUrlDataType &other);
    UaNetworkAddressUrlDataType(const OpcUa_NetworkAddressUrlDataType &other);
    UaNetworkAddressUrlDataType(
        const UaString& networkInterface,
        const UaString& url
        );
    UaNetworkAddressUrlDataType(const UaExtensionObject &extensionObject);
    UaNetworkAddressUrlDataType(const OpcUa_ExtensionObject &extensionObject);
    UaNetworkAddressUrlDataType(UaExtensionObject &extensionObject, OpcUa_Boolean bDetach);
    UaNetworkAddressUrlDataType(OpcUa_ExtensionObject &extensionObject, OpcUa_Boolean bDetach);
    ~UaNetworkAddressUrlDataType();

    void clear();

    bool operator==(const UaNetworkAddressUrlDataType &other) const;
    bool operator!=(const UaNetworkAddressUrlDataType &other) const;

    UaNetworkAddressUrlDataType& operator=(const UaNetworkAddressUrlDataType &other);

    OpcUa_NetworkAddressUrlDataType* copy() const;
    void copyTo(OpcUa_NetworkAddressUrlDataType *pDst) const;

    static OpcUa_NetworkAddressUrlDataType* clone(const OpcUa_NetworkAddressUrlDataType& source);
    static void cloneTo(const OpcUa_NetworkAddressUrlDataType& source, OpcUa_NetworkAddressUrlDataType& copy);

    void attach(OpcUa_NetworkAddressUrlDataType *pValue);
    OpcUa_NetworkAddressUrlDataType* detach(OpcUa_NetworkAddressUrlDataType* pDst);

    void toVariant(UaVariant &variant) const;
    void toVariant(OpcUa_Variant &variant) const;
    void toVariant(UaVariant &variant, OpcUa_Boolean bDetach);
    void toVariant(OpcUa_Variant &variant, OpcUa_Boolean bDetach);

    void toDataValue(UaDataValue &dataValue, OpcUa_Boolean updateTimeStamps) const;
    void toDataValue(OpcUa_DataValue &dataValue, OpcUa_Boolean updateTimeStamps) const;
    void toDataValue(UaDataValue &dataValue, OpcUa_Boolean bDetach, OpcUa_Boolean updateTimeStamps);
    void toDataValue(OpcUa_DataValue &dataValue, OpcUa_Boolean bDetach, OpcUa_Boolean updateTimeStamps);

    void toExtensionObject(UaExtensionObject &extensionObject) const;
    void toExtensionObject(OpcUa_ExtensionObject &extensionObject) const;
    void toExtensionObject(UaExtensionObject &extensionObject, OpcUa_Boolean bDetach);
    void toExtensionObject(OpcUa_ExtensionObject &extensionObject, OpcUa_Boolean bDetach);

    OpcUa_StatusCode setNetworkAddressUrlDataType(const UaExtensionObject &extensionObject);
    OpcUa_StatusCode setNetworkAddressUrlDataType(const OpcUa_ExtensionObject &extensionObject);
    OpcUa_StatusCode setNetworkAddressUrlDataType(UaExtensionObject &extensionObject, OpcUa_Boolean bDetach);
    OpcUa_StatusCode setNetworkAddressUrlDataType(OpcUa_ExtensionObject &extensionObject, OpcUa_Boolean bDetach);

    void setNetworkAddressUrlDataType(
        const UaString& networkInterface,
        const UaString& url
        );

    UaString getNetworkInterface() const;
    UaString getUrl() const;

    void setNetworkInterface(const UaString& networkInterface);
    void setUrl(const UaString& url);
};

/** @ingroup CppBaseLibraryClass
 *  @brief Array class for the UA stack structure OpcUa_NetworkAddressUrlDataType.
 *
 *  This class encapsulates an array of the native OpcUa_NetworkAddressUrlDataType structure
 *  and handles memory allocation and cleanup for you.
 *  @see UaNetworkAddressUrlDataType for information about the encapsulated structure.
 */
class UABASE_EXPORT UaNetworkAddressUrlDataTypes
{
public:
    UaNetworkAddressUrlDataTypes();
    UaNetworkAddressUrlDataTypes(const UaNetworkAddressUrlDataTypes &other);
    UaNetworkAddressUrlDataTypes(OpcUa_Int32 length, OpcUa_NetworkAddressUrlDataType* data);
    virtual ~UaNetworkAddressUrlDataTypes();

    UaNetworkAddressUrlDataTypes& operator=(const UaNetworkAddressUrlDataTypes &other);
    const OpcUa_NetworkAddressUrlDataType& operator[](OpcUa_UInt32 index) const;
    OpcUa_NetworkAddressUrlDataType& operator[](OpcUa_UInt32 index);

    bool operator==(const UaNetworkAddressUrlDataTypes &other) const;
    bool operator!=(const UaNetworkAddressUrlDataTypes &other) const;

    void attach(OpcUa_UInt32 length, OpcUa_NetworkAddressUrlDataType* data);
    void attach(OpcUa_Int32 length, OpcUa_NetworkAddressUrlDataType* data);
    OpcUa_NetworkAddressUrlDataType* detach();

    void create(OpcUa_UInt32 length);
    void resize(OpcUa_UInt32 length);
    void clear();

    inline OpcUa_UInt32 length() const {return m_noOfElements;}
    inline const OpcUa_NetworkAddressUrlDataType* rawData() const {return m_data;}
    inline OpcUa_NetworkAddressUrlDataType* rawData() {return m_data;}

    void toVariant(UaVariant &variant) const;
    void toVariant(OpcUa_Variant &variant) const;
    void toVariant(UaVariant &variant, OpcUa_Boolean bDetach);
    void toVariant(OpcUa_Variant &variant, OpcUa_Boolean bDetach);

    void toDataValue(UaDataValue &dataValue, OpcUa_Boolean updateTimeStamps) const;
    void toDataValue(OpcUa_DataValue &dataValue, OpcUa_Boolean updateTimeStamps) const;
    void toDataValue(UaDataValue &dataValue, OpcUa_Boolean bDetach, OpcUa_Boolean updateTimeStamps);
    void toDataValue(OpcUa_DataValue &dataValue, OpcUa_Boolean bDetach, OpcUa_Boolean updateTimeStamps);

    OpcUa_StatusCode setNetworkAddressUrlDataTypes(const UaVariant &variant);
    OpcUa_StatusCode setNetworkAddressUrlDataTypes(const OpcUa_Variant &variant);
    OpcUa_StatusCode setNetworkAddressUrlDataTypes(UaVariant &variant, OpcUa_Boolean bDetach);
    OpcUa_StatusCode setNetworkAddressUrlDataTypes(OpcUa_Variant &variant, OpcUa_Boolean bDetach);
    OpcUa_StatusCode setNetworkAddressUrlDataTypes(OpcUa_Int32 length, OpcUa_NetworkAddressUrlDataType* data);

private:
    OpcUa_UInt32 m_noOfElements;
    OpcUa_NetworkAddressUrlDataType* m_data;
};

#endif // UANETWORKADDRESSURLDATATYPE_H

