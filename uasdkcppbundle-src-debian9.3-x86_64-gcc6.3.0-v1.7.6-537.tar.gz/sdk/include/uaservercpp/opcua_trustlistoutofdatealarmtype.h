/******************************************************************************
** opcua_trustlistoutofdatealarmtype.h
**
** Copyright (c) 2006-2022 Unified Automation GmbH. All rights reserved.
**
** Software License Agreement ("SLA") Version 2.7
**
** Unless explicitly acquired and licensed from Licensor under another
** license, the contents of this file are subject to the Software License
** Agreement ("SLA") Version 2.7, or subsequent versions
** as allowed by the SLA, and You may not copy or use this file in either
** source code or executable form, except in compliance with the terms and
** conditions of the SLA.
**
** All software distributed under the SLA is provided strictly on an
** "AS IS" basis, WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESS OR IMPLIED,
** AND LICENSOR HEREBY DISCLAIMS ALL SUCH WARRANTIES, INCLUDING WITHOUT
** LIMITATION, ANY WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
** PURPOSE, QUIET ENJOYMENT, OR NON-INFRINGEMENT. See the SLA for specific
** language governing rights and limitations under the SLA.
**
** The complete license agreement can be found here:
** http://unifiedautomation.com/License/SLA/2.7/
**
** Project: C++ OPC Server SDK information model for namespace http://opcfoundation.org/UA/
**
** Description: OPC Unified Architecture Software Development Kit.
**
******************************************************************************/

#ifndef __OPCUA_TRUSTLISTOUTOFDATEALARMTYPE_H__
#define __OPCUA_TRUSTLISTOUTOFDATEALARMTYPE_H__

#include "opcua_systemoffnormalalarmtype.h"
#include "basenodes.h"
#include "opcua_identifiers.h"
#include "opcua_propertytype.h"

// Namespace for the UA information model http://opcfoundation.org/UA/
namespace OpcUa {

class TrustListOutOfDateAlarmType;
class PropertyType;

/** Generated event data class for a TrustListOutOfDateAlarmType.
 *
 *  This class contains the auto generated code for the object type TrustListOutOfDateAlarmType
 *  providing UaEventData interface for the access to event data containing the current state of the
 *  condition for events sent to the client. The class is used for condition events if the condition has
 *  no nodes in the address space or for condition branches created as snapshot of the main branch.
 *
 *  **Event Fields of the TrustListOutOfDateAlarmType:**
 *
 *  Browse Name     | DataType | TypeDefinition | Modelling Rule | See Also
 *  ----------------|----------|----------------|----------------|-------------------------------------------------
 *  LastUpdateTime  | UtcTime  | PropertyType   | Mandatory      | \ref getLastUpdateTime, \ref setLastUpdateTime
 *  TrustListId     | NodeId   | PropertyType   | Mandatory      | \ref getTrustListId, \ref setTrustListId
 *  UpdateFrequency | Duration | PropertyType   | Mandatory      | \ref getUpdateFrequency, \ref setUpdateFrequency

 */
class SERVER_CORE_EXPORT TrustListOutOfDateAlarmTypeData:
    public OpcUa::SystemOffNormalAlarmTypeData
{
    UA_DISABLE_COPY(TrustListOutOfDateAlarmTypeData);
protected:
    virtual ~TrustListOutOfDateAlarmTypeData();
public:
    TrustListOutOfDateAlarmTypeData();
    void initializeAsBranch(TrustListOutOfDateAlarmType* pCondition);
    void initializeAsBranch(TrustListOutOfDateAlarmTypeData* pConditionData);
    virtual void getFieldData(OpcUa_UInt32 index, Session* pSession, OpcUa_Variant& data);
    // LastUpdateTime
    void setLastUpdateTime(const UaDateTime& LastUpdateTime);
    void setLastUpdateTimeStatus(OpcUa_StatusCode status);
    UaDateTime getLastUpdateTime();
    virtual void getLastUpdateTimeValue(Session* pSession, OpcUa_Variant& value);
    // TrustListId
    void setTrustListId(const UaNodeId& TrustListId);
    void setTrustListIdStatus(OpcUa_StatusCode status);
    UaNodeId getTrustListId();
    virtual void getTrustListIdValue(Session* pSession, OpcUa_Variant& value);
    // UpdateFrequency
    void setUpdateFrequency(OpcUa_Double UpdateFrequency);
    void setUpdateFrequencyStatus(OpcUa_StatusCode status);
    OpcUa_Double getUpdateFrequency();
    virtual void getUpdateFrequencyValue(Session* pSession, OpcUa_Variant& value);


private:
    void initialize();

private:
    UaObjectPointerArray<UaVariant> m_FieldValues;
};


/** @brief Class implementing the UaObject interface for the TrustListOutOfDateAlarmType.
 *
 * OPC UA Objects are used to represent systems, system components, real-world objects and software
 * objects. They have the NodeClass @ref L3UaNodeClassObject. The detailed description of Objects and their attributes
 * can be found in the general description of the @ref L3UaNodeClassObject node class.
 *
 *  **Variable members of the TrustListOutOfDateAlarmType:**
 *
 *  Browse Name     | DataType | TypeDefinition | Modelling Rule | See Also
 *  ----------------|----------|----------------|----------------|-------------------------------------------------
 *  LastUpdateTime  | UtcTime  | PropertyType   | Mandatory      | \ref getLastUpdateTime, \ref setLastUpdateTime
 *  TrustListId     | NodeId   | PropertyType   | Mandatory      | \ref getTrustListId, \ref setTrustListId
 *  UpdateFrequency | Duration | PropertyType   | Mandatory      | \ref getUpdateFrequency, \ref setUpdateFrequency
 *
 */
class SERVER_CORE_EXPORT TrustListOutOfDateAlarmType:
    public OpcUa::SystemOffNormalAlarmType
{
    friend class TrustListOutOfDateAlarmTypeData;
    UA_DISABLE_COPY(TrustListOutOfDateAlarmType);
protected:
    // destruction
    virtual ~TrustListOutOfDateAlarmType();
public:
    // construction
    TrustListOutOfDateAlarmType(const UaNodeId& nodeId, UaObject* pInstanceDeclarationObject, NodeManagerConfig* pNodeConfig, const UaNodeId& sourceNode, const UaString& sourceName, UaMutexRefCounted* pSharedMutex = NULL);
    TrustListOutOfDateAlarmType(const UaNodeId& nodeId, const UaString& name, OpcUa_UInt16 browseNameNameSpaceIndex, NodeManagerConfig* pNodeConfig, const UaNodeId& sourceNode, const UaString& sourceName, UaMutexRefCounted* pSharedMutex = NULL);
    TrustListOutOfDateAlarmType(
        UaBase::Object*    pBaseNode,
        XmlUaNodeFactoryManager*   pFactory,
        NodeManagerConfig* pNodeConfig,
        UaMutexRefCounted* pSharedMutex = NULL);

    static void createTypes();
    static void clearStaticMembers();
    virtual UaNodeId typeDefinitionId() const;
    static void registerEventFields();
    static OpcUa_UInt32 registerOptionalEventFields(const UaString& fieldName);
    virtual void getFieldData(OpcUa_UInt32 index, Session* pSession, OpcUa_Variant& data);
    void clearFieldData();
    UaNodeId createBranch();


    // LastUpdateTime
    virtual void setLastUpdateTime(const UaDateTime& LastUpdateTime);
    virtual UaDateTime getLastUpdateTime() const;
    virtual void setLastUpdateTimeStatus(OpcUa_StatusCode status);
    virtual void getLastUpdateTimeValue(Session* pSession, UaVariant& value);
    // TrustListId
    virtual void setTrustListId(const UaNodeId& TrustListId);
    virtual UaNodeId getTrustListId() const;
    virtual void setTrustListIdStatus(OpcUa_StatusCode status);
    virtual void getTrustListIdValue(Session* pSession, UaVariant& value);
    // UpdateFrequency
    virtual void setUpdateFrequency(OpcUa_Double UpdateFrequency);
    virtual OpcUa_Double getUpdateFrequency() const;
    virtual void setUpdateFrequencyStatus(OpcUa_StatusCode status);
    virtual void getUpdateFrequencyValue(Session* pSession, UaVariant& value);

    virtual OpcUa::PropertyType* getLastUpdateTimeNode();
    virtual const OpcUa::PropertyType* getLastUpdateTimeNode() const;
    virtual OpcUa::PropertyType* getTrustListIdNode();
    virtual const OpcUa::PropertyType* getTrustListIdNode() const;
    virtual OpcUa::PropertyType* getUpdateFrequencyNode();
    virtual const OpcUa::PropertyType* getUpdateFrequencyNode() const;

    // NodeAccessInfo management
    virtual void useAccessInfoFromType();
    void useAccessInfoFromInstance(TrustListOutOfDateAlarmType *pInstance);

    virtual UaStatus triggerEvent(
        const UaDateTime&   time,
        const UaDateTime&   receiveTime,
        const UaByteString& eventId);

    virtual void getTrustListOutOfDateAlarmTypeOptionalFieldData(OpcUa_UInt32 index, Session* pSession, OpcUa_Variant& data);

protected:
    // Variable nodes
    // Variable LastUpdateTime
    static OpcUa::PropertyType*  s_pLastUpdateTime;
    OpcUa::PropertyType*  m_pLastUpdateTime;
    // Variable TrustListId
    static OpcUa::PropertyType*  s_pTrustListId;
    OpcUa::PropertyType*  m_pTrustListId;
    // Variable UpdateFrequency
    static OpcUa::PropertyType*  s_pUpdateFrequency;
    OpcUa::PropertyType*  m_pUpdateFrequency;



private:
    void initialize();
    void createChildren();

private:
    static bool                                 s_typeNodesCreated;
    static std::map<OpcUa_UInt32, OpcUa_UInt32> s_TrustListOutOfDateAlarmTypeDataFields;
    UaObjectPointerArray<UaVariant>             m_FieldValues;
};

} // End namespace for the UA information model http://opcfoundation.org/UA/

#endif // #ifndef __OPCUA_TRUSTLISTOUTOFDATEALARMTYPE_H__

