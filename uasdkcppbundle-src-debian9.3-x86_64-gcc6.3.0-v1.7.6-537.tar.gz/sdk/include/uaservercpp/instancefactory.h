/******************************************************************************
** instancefactory.h
**
** Copyright (c) 2006-2022 Unified Automation GmbH. All rights reserved.
**
** Software License Agreement ("SLA") Version 2.7
**
** Unless explicitly acquired and licensed from Licensor under another
** license, the contents of this file are subject to the Software License
** Agreement ("SLA") Version 2.7, or subsequent versions
** as allowed by the SLA, and You may not copy or use this file in either
** source code or executable form, except in compliance with the terms and
** conditions of the SLA.
**
** All software distributed under the SLA is provided strictly on an
** "AS IS" basis, WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESS OR IMPLIED,
** AND LICENSOR HEREBY DISCLAIMS ALL SUCH WARRANTIES, INCLUDING WITHOUT
** LIMITATION, ANY WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
** PURPOSE, QUIET ENJOYMENT, OR NON-INFRINGEMENT. See the SLA for specific
** language governing rights and limitations under the SLA.
**
** The complete license agreement can be found here:
** http://unifiedautomation.com/License/SLA/2.7/
**
** Project: C++ OPC Server SDK core module
**
** Description: OPC server core module internal transactions.
**
******************************************************************************/
#ifndef XMLUANODEFACTORYMANAGER_H
#define XMLUANODEFACTORYMANAGER_H

#include "basenodes.h"
#include "opcua_basevariabletype.h"
#include "opcua_baseobjecttype.h"
#include <map>
#include <list>

class XmlUaNodeFactoryManager;

/** Abstract factory for creating Variables or Objects for a type namespace.
 *
 * This interface is used to create instances of Objects and Variables where
 * generated C++ classes exist for the corresponding ObjectTypes and VariableTypes.
 * The generated code for these namespaces contains the corresponding factory
 * class for this namespace.
 *
 * This class provides an interface for creating UaNodes and its children depending on
 * \ref UaBase::BaseNode "UaBase::BaseNodes" and for adding the new nodes to a
 * NodeManagerConfig. The TypeDefinition of the UaBase::BaseNode can be used to
 * create an instance of a toolkit class.
 *
 * Subtypes of this class are used by XmlUaNodeFactoryManager.
 */
class SERVER_CORE_EXPORT XmlUaNodeFactoryNamespace
{
    friend class XmlUaNodeFactoryManager;
    XmlUaNodeFactoryNamespace();
public:
    XmlUaNodeFactoryNamespace(OpcUa_UInt16 namespaceIndex);
    XmlUaNodeFactoryNamespace(const UaString& namespaceUri);
    virtual ~XmlUaNodeFactoryNamespace(){}

    virtual UaVariable* createVariable(
        UaBase::Variable *pVariable,
        XmlUaNodeFactoryManager *pFactory,
        NodeManagerConfig* pNodeConfig,
        UaMutexRefCounted* pSharedMutex = NULL) = 0;
    virtual UaObject* createObject(
        UaBase::Object *pObject,
        XmlUaNodeFactoryManager *pFactory,
        NodeManagerConfig* pNodeConfig,
        UaMutexRefCounted* pSharedMutex = NULL) = 0;

    OpcUa_UInt16 namespaceIndex() const;

    virtual OpcUa::BaseVariableTypeGeneric* createGenericVariable(
        UaBase::Variable *pVariable,
        XmlUaNodeFactoryManager *pFactory,
        NodeManagerConfig* pNodeConfig,
        UaMutexRefCounted* pSharedMutex);
    virtual OpcUa::BaseObjectTypeGeneric* createGenericObject(
        UaBase::Object *pObject,
        XmlUaNodeFactoryManager *pFactory,
        NodeManagerConfig* pNodeConfig,
        UaMutexRefCounted* pSharedMutex);
    virtual OpcUa::BaseMethod* createGenericMethod(
        UaBase::Method *pMethod,
        XmlUaNodeFactoryManager *pFactory,
        NodeManagerConfig* pNodeConfig,
        UaMutexRefCounted* pSharedMutex);
    virtual UaVariant defaultValue(const UaNodeId &dataTypeId, OpcUa_Int32 valueRank) const = 0;
    virtual void createType(const UaNodeId &typeId) const;

private:
    OpcUa_UInt16 m_namespaceIndex;
    UaString     m_namespaceUri;
    bool         m_isNamespaceIndexSet;
};

/** This class is the factory for creating instances of ObjectTypes and VariableType
 * defined in namespace 0.*/
class SERVER_CORE_EXPORT XmlUaNodeFactoryNamespace0 : public XmlUaNodeFactoryNamespace
{
public:
    XmlUaNodeFactoryNamespace0();

    virtual UaVariable* createVariable(
        UaBase::Variable *pVariable,
        XmlUaNodeFactoryManager *pFactory,
        NodeManagerConfig* pNodeConfig,
        UaMutexRefCounted* pSharedMutex = NULL);
    virtual UaObject* createObject(
        UaBase::Object *pObject,
        XmlUaNodeFactoryManager *pFactory,
        NodeManagerConfig* pNodeConfig,
        UaMutexRefCounted* pSharedMutex = NULL);
    virtual UaVariant defaultValue(const UaNodeId &dataTypeId, OpcUa_Int32 valueRank) const;
    virtual void createType(const UaNodeId &typeId) const;

    static void setAdditionalFactory(XmlUaNodeFactoryNamespace* pAdditionalFactory) { s_pAdditionalFactory = pAdditionalFactory; }
private:
    static XmlUaNodeFactoryNamespace* s_pAdditionalFactory;
};

/** The manager of the factories for creating instances.
 *
 * The main use case for this class is to parse a NodeSet XML file using NodeManagerNodeSetXml
 * and to create instances of toolkit classes using the resulting \ref UaBase::BaseNode
 * "UaBase::BaseNodes".
 */
class SERVER_CORE_EXPORT XmlUaNodeFactoryManager
{
public:
    XmlUaNodeFactoryManager();
    virtual ~XmlUaNodeFactoryManager();
    UaStatus startUp(ServerManager *pServerManager);
    void addNamespace(XmlUaNodeFactoryNamespace *pFactoryNamespace, bool deleteAtShutdown = false);

    UaVariable* createVariable(
        UaBase::Variable *pVariable,
        NodeManagerConfig* pNodeConfig,
        UaMutexRefCounted* pSharedMutex = NULL);
    UaObject* createObject(
        UaBase::Object *pObject,
        NodeManagerConfig* pNodeConfig,
        UaMutexRefCounted* pSharedMutex = NULL);
    virtual UaMethod* createMethod(
        UaBase::Method *pMethod,
        NodeManagerConfig* pNodeConfig,
        UaMutexRefCounted* pSharedMutex = NULL);
    virtual UaDataType* createDataType(
        UaBase::DataType *pDataType,
        NodeManagerConfig* pNodeConfig,
        UaMutexRefCounted* pSharedMutex = NULL);
    virtual UaReferenceType* createReferenceType(
        UaBase::ReferenceType *pReferenceType,
        NodeManagerConfig* pNodeConfig,
        UaMutexRefCounted* pSharedMutex = NULL);
    virtual UaObjectType* createObjectType(
        UaBase::ObjectType *pObjectType,
        NodeManagerConfig* pNodeConfig,
        UaMutexRefCounted* pSharedMutex = NULL);
    virtual UaVariableType* createVariableType(
        UaBase::VariableType *pVariableType,
        NodeManagerConfig* pNodeConfig,
        UaMutexRefCounted* pSharedMutex = NULL);

    UaVariant defaultValue(const UaNodeId &dataTypeId, OpcUa_Int32 valueRank) const;
    virtual void createType(const UaNodeId &typeId);

protected:
    virtual OpcUa::BaseMethod* createBaseMethod(UaBase::Method *pMethod, UaMutexRefCounted* pSharedMutex);

private:
    std::map<OpcUa_UInt16, XmlUaNodeFactoryNamespace*> m_mapFactories;
    XmlUaNodeFactoryNamespace0 m_namespace0;
    std::map<UaNodeId, UaEnumDefinition> m_customEnumerations;
    std::list<XmlUaNodeFactoryNamespace*> m_listFactoriesToDelete;
    std::list<XmlUaNodeFactoryNamespace*> m_listFactoriesToCreateIndex;
    ServerManager* m_pServerManager;
};
#endif // INSTANCEFACTORY_H
