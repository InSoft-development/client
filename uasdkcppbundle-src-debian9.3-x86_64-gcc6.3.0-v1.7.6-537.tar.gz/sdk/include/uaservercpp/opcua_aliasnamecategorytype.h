/******************************************************************************
** opcua_aliasnamecategorytype.h
**
** Copyright (c) 2006-2022 Unified Automation GmbH. All rights reserved.
**
** Software License Agreement ("SLA") Version 2.7
**
** Unless explicitly acquired and licensed from Licensor under another
** license, the contents of this file are subject to the Software License
** Agreement ("SLA") Version 2.7, or subsequent versions
** as allowed by the SLA, and You may not copy or use this file in either
** source code or executable form, except in compliance with the terms and
** conditions of the SLA.
**
** All software distributed under the SLA is provided strictly on an
** "AS IS" basis, WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESS OR IMPLIED,
** AND LICENSOR HEREBY DISCLAIMS ALL SUCH WARRANTIES, INCLUDING WITHOUT
** LIMITATION, ANY WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
** PURPOSE, QUIET ENJOYMENT, OR NON-INFRINGEMENT. See the SLA for specific
** language governing rights and limitations under the SLA.
**
** The complete license agreement can be found here:
** http://unifiedautomation.com/License/SLA/2.7/
**
** Project: C++ OPC Server SDK information model for namespace http://opcfoundation.org/UA/
**
** Description: OPC Unified Architecture Software Development Kit.
**
******************************************************************************/

#ifndef __OPCUA_ALIASNAMECATEGORYTYPE_H__
#define __OPCUA_ALIASNAMECATEGORYTYPE_H__

#include "opcua_aliasnamecategorytypebase.h"

// Namespace for the UA information model http://opcfoundation.org/UA/
namespace OpcUa {

class SERVER_CORE_EXPORT AliasNameCategoryType;

/** Callback interface for handling incoming AliasNameCategory Method calls
 */
class SERVER_CORE_EXPORT AliasNameCategoryTypeCallback
{
public:
    AliasNameCategoryTypeCallback(){}
    virtual ~AliasNameCategoryTypeCallback(){}

    /**
     *  Obtaina a list of Nodes that match the provided AliasName search string.
     *
     *  <b>Method Result Codes</b>
     *
     *  Result Code               | Description
     *  --------------------------|-----------------------------------------------------------------------
     *  Bad_InvalidArgument       | The input string is not a valid search sting.
     *  Bad_UserAccessDenied      | The current user does not have the rights required.
     *  Bad_ResponseToLarge       | The response was to large to be returned, try new filter and repeat find.
     */
    virtual UaStatus FindAlias(
        const ServiceContext& serviceContext /**<General context for the service calls containing
                                                 information like the session object,
                                                 return diagnostic mask and timeout hint.*/,
        const UaString& AliasNameSearchPattern, /**<[in] A string that can contain wild cards. */
        const UaNodeId& ReferenceTypeFilter,    /**<[in] A NodeId that represent a ReferenceType (i.e. AliasFor or one of its subtypes) that restricts
                                                         the search. Any ReferenceType includes all subtypes of that ReferenceType. */
        UaAliasNameDataTypes& AliasNodeList,    /**<[out] The returned list of AliasNameDataType. If no Nodes match the search string or have
                                                          the appropriate ReferenceType, the list is empty. */
        AliasNameCategoryType* pAliasNameCategory /**< Affected Object Node.*/
        ) = 0;
};


/** @brief Class implementing the UaObject interface for the AliasNameCategoryType.
 *
 * OPC UA Objects are used to represent systems, system components, real-world objects and software
 * objects. They have the NodeClass @ref L3UaNodeClassObject. The detailed description of Objects and their attributes
 * can be found in the general description of the @ref L3UaNodeClassObject node class.
 *
 *  **Object members of the AliasNameCategoryType:**
 *
 *  Browse Name                | TypeDefinition        | Modelling Rule      | See Also
 *  ---------------------------|-----------------------|---------------------|---------
 *  \<Alias\>                  | AliasNameType         | OptionalPlaceholder | &nbsp;
 *  \<SubAliasNameCategories\> | AliasNameCategoryType | OptionalPlaceholder | &nbsp;
 *
 *  **Method members of the AliasNameCategoryType:**
 *
 *  Browse Name    | Modelling Rule
 *  ---------------|---------------
 *  \ref FindAlias | Mandatory
 *
 *  https://reference.opcfoundation.org/v104/Core/docs/Part17/6.3.1
 */
class SERVER_CORE_EXPORT AliasNameCategoryType:
    public AliasNameCategoryTypeBase
{
    UA_DISABLE_COPY(AliasNameCategoryType);
protected:
    // destruction
    virtual ~AliasNameCategoryType();
public:
    // construction
    AliasNameCategoryType(const UaNodeId& nodeId, UaObject* pInstanceDeclarationObject, NodeManagerConfig* pNodeConfig, UaMutexRefCounted* pSharedMutex = NULL);
    AliasNameCategoryType(const UaNodeId& nodeId, const UaString& name, OpcUa_UInt16 browseNameNameSpaceIndex, NodeManagerConfig* pNodeConfig, UaMutexRefCounted* pSharedMutex = NULL);
    AliasNameCategoryType(
        UaBase::Object*    pBaseNode,
        XmlUaNodeFactoryManager*   pFactory,
        NodeManagerConfig* pNodeConfig,
        UaMutexRefCounted* pSharedMutex = NULL);
    static void createTypes();
    static void clearStaticMembers();

    void setCallback(AliasNameCategoryTypeCallback* pCallback);
    static void setDefaultCallback(AliasNameCategoryTypeCallback* pCallback);

    // UaAliasNameCategoryType method FindAlias
    virtual UaStatus FindAlias(
        const ServiceContext& serviceContext,
        const UaString& AliasNameSearchPattern,
        const UaNodeId& ReferenceTypeFilter,
        UaAliasNameDataTypes& AliasNodeList);

protected:

private:
    static bool s_typeNodesCreated;
    AliasNameCategoryTypeCallback* m_pCallback;
    static AliasNameCategoryTypeCallback* s_pCallback;
};

} // End namespace for the UA information model http://opcfoundation.org/UA/

#endif // #ifndef __OPCUAALIASNAMECATEGORYTYPE_H__

