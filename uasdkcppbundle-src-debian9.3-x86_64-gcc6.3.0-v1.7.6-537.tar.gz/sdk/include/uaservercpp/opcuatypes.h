/******************************************************************************
** opcuatypes.h
**
** Copyright (c) 2006-2022 Unified Automation GmbH. All rights reserved.
**
** Software License Agreement ("SLA") Version 2.7
**
** Unless explicitly acquired and licensed from Licensor under another
** license, the contents of this file are subject to the Software License
** Agreement ("SLA") Version 2.7, or subsequent versions
** as allowed by the SLA, and You may not copy or use this file in either
** source code or executable form, except in compliance with the terms and
** conditions of the SLA.
**
** All software distributed under the SLA is provided strictly on an
** "AS IS" basis, WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESS OR IMPLIED,
** AND LICENSOR HEREBY DISCLAIMS ALL SUCH WARRANTIES, INCLUDING WITHOUT
** LIMITATION, ANY WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
** PURPOSE, QUIET ENJOYMENT, OR NON-INFRINGEMENT. See the SLA for specific
** language governing rights and limitations under the SLA.
**
** The complete license agreement can be found here:
** http://unifiedautomation.com/License/SLA/2.7/
**
** Project: C++ OPC Server SDK core module
**
** Description: OPC server core module base types.
**
******************************************************************************/
#ifndef OPCUATYPES_H
#define OPCUATYPES_H

#ifdef _WIN32
# ifdef _SERVER_CORE_BUILD_DLL
#  define SERVER_CORE_EXPORT __declspec(dllexport)
# elif defined _SERVER_CORE_USE_DLL
#  define SERVER_CORE_EXPORT __declspec(dllimport)
# else
#  define SERVER_CORE_EXPORT
# endif
#else
# define SERVER_CORE_EXPORT
#endif

#include "opcua_proxystub.h"
#include "statuscode.h"
#include "uastring.h"
#include "uavariant.h"
#include "uamutex.h"
#include "uadatetime.h"
#include <list>

class SERVER_CORE_EXPORT Session;
class SERVER_CORE_EXPORT SessionUserContext;
class SERVER_CORE_EXPORT NodeAccessInfo;
class SERVER_CORE_EXPORT NodeManager;

/** @brief This class provides the context for a Service invocation.

* This context contains the Session object used for the Service call and the general client side settings like the timeout hint and
* the level of requested diagnostic information.
*/
class SERVER_CORE_EXPORT ServiceContext
{
public:
    // construction / destruction
    ServiceContext();
    virtual ~ServiceContext();
    ServiceContext(const ServiceContext &);
    ServiceContext& operator=(const ServiceContext&);

    /**  Returns the Session object.
    *
    * The Session object is reference counted. The Session is valid until the client has closed the Session or it timed out.
    * If the Session pointer is stored in user objects, these objects must add their own reference.
    */
    inline Session*     pSession() const {return m_pSession;}

    // Returns the SessionUserContext object.
    const SessionUserContext* pSessionUserContext() const;

    /**  Returns the timeout hint in milliseconds set by the client for this service invocation.
    * A client side stack returns an timeout error to the caller after the timeout expired.
    */
    inline OpcUa_UInt32 timeoutHint() const {return m_timeoutHint;}

    /** Returns the timestamp the server received this service invocation. */
    inline UaDateTime   receiveTime() const {return m_receiveTime;}

    /**  Returns the timestamp set by the client for this service invocation.*/
    inline UaDateTime   clientTime() const {return m_clientTime;}

    /**  Returns the client requested diagnostic level for this service invocation.
    * Bit mask that defines the diagnostic information to be returned from the server.<br>
    * Bit Value --- Diagnostics to return -------------- Define<br>
    * 0x0000 0001 - ServiceLevel / SymbolicId ---------- OpcUa_DiagnosticsMasks_ServiceSymbolicId<br>
    * 0x0000 0002 - ServiceLevel / LocalizedText ------- OpcUa_DiagnosticsMasks_ServiceLocalizedText<br>
    * 0x0000 0004 - ServiceLevel / AdditionalInfo ------ OpcUa_DiagnosticsMasks_ServiceAdditionalInfo<br>
    * 0x0000 0008 - ServiceLevel / Inner StatusCode ---- OpcUa_DiagnosticsMasks_ServiceInnerStatusCode<br>
    * 0x0000 0010 - ServiceLevel / Inner Diagnostics --- OpcUa_DiagnosticsMasks_ServiceInnerDiagnostics<br>
    * 0x0000 0020 - OperationLevel / SymbolicId -------- OpcUa_DiagnosticsMasks_OperationSymbolicId<br>
    * 0x0000 0040 - OperationLevel / LocalizedText ----- OpcUa_DiagnosticsMasks_OperationLocalizedText<br>
    * 0x0000 0080 - OperationLevel / AdditionalInfo ---- OpcUa_DiagnosticsMasks_OperationAdditionalInfo<br>
    * 0x0000 0100 - OperationLevel / Inner StatusCode -- OpcUa_DiagnosticsMasks_OperationInnerStatusCode<br>
    * 0x0000 0200 - OperationLevel / Inner Diagnostics - OpcUa_DiagnosticsMasks_OperationInnerDiagnostics<br>
    */
    inline OpcUa_UInt32 returnDiagnostics() const {return m_returnDiagnostics;}

    /**  Returns the request handle set by the client for this service invocation.
    */
    inline OpcUa_UInt32 requestHandle() const {return m_requestHandle;}

    /**  Returns the AuditEntryId set by the client for this service invocation.
    */
    inline UaString clientAuditEntryId() const {return m_sClientAuditEntryId;}

    // Sets the Service context with information provided by the client in the request header and with the session object related to the request
    void setContext(
        Session*                   pSession,
        const OpcUa_RequestHeader& header);
    // Sets the Session object.
    void setSession(Session* pSession);
    // Set the client requested diagnostic level for this service invocation.
    void setReturnDiagnostics(OpcUa_UInt32 returnDiagnostics);
    void setTimeoutHint(OpcUa_UInt32 timeoutHint);

    // Set or get the mutex for the node list in a NodeManager
    void setNodeManagementMutex(UaMutex* pMutex);
    UaMutex* getNodeManagementMutex() const;
private:
    Session*      m_pSession;
    OpcUa_UInt32  m_timeoutHint;
    UaDateTime    m_receiveTime;
    UaDateTime    m_clientTime;
    OpcUa_UInt32  m_returnDiagnostics;
    OpcUa_UInt32  m_requestHandle;
    UaString      m_sClientAuditEntryId;
    UaMutex*      m_pNodeManagementMutex;
};

/*
 *  Context filled by a NodeManager while processing translateBrowsePathToNodeId if there are references to
 *  another NodeManager.
 *  This context is then used by the SDK to call translateBrowsePathToNodeId again for those Nodemanagers.
 *  That is typically necessary whenever a CrossNodeManager Reference was found while processing translateBrowsePathToNodeId.
*/
class SERVER_CORE_EXPORT UaTranslateBrowsePathContext
{
public:
    UaTranslateBrowsePathContext(NodeManager*     pNodeMgr,
                                  UaNodeId        startingNodeId,
                                  OpcUa_UInt32    indexContinue)
        : pNodeManager(pNodeMgr), startingNode(startingNodeId), indexToContinue(indexContinue)
    {}
    NodeManager*    pNodeManager;       // NodeManager to call Translate
    UaNodeId        startingNode;       // NodeId to pass in as starting node to translateBrowsePathToNodeId
    OpcUa_UInt32    indexToContinue;    // index in UaRelativePath for next call to translateBrowsePathToNodeId
};

/** @brief This class manages a relative path used for TranslatBrowsePathsToNodeIds.

 *  The relative path contains a list of path elements where each path element contains the reference type
 *  to follow and the browse name of the target node. This path is used to find a target node by starting at a
 *  starting node and by following the path. This class manages the relative path and the current position in the
 *  path.
 *
 *  To process one element of the path a pointer to the current path element can be requested by using the function getElementAtCurrentPosition().
 *  If the current position contained a valid reference and browse path and a matching node was found at this level, the position
 *  will be incremented by the caller (NodeManagerRoot).
 *
 *  To process a several path elements, getElementAt() is used starting from the index provided by currentPosition().
 *
 *  If a NodeManager finds references to another NodeManager it adds those by calling addNodeManagerToProcess().
 */
class SERVER_CORE_EXPORT UaRelativePath
{
    UaRelativePath &operator=(const UaRelativePath &);
public:
    /* construction */
    UaRelativePath();
    UaRelativePath(const OpcUa_RelativePath& relativePath);
    UaRelativePath(const UaQualifiedNameArray& browsePath);
    UaRelativePath(const UaRelativePathElements& elements);
    UaRelativePath(const UaRelativePath&);
    /* destruction */
    virtual ~UaRelativePath();

    void clear();

    void copyTo(OpcUa_RelativePath *pDst) const;

    /** Get the current position in the array of relative path elements.
     *  @return The current position in the list of RelativePathElement as zero based index.
     */
    inline OpcUa_UInt32 currentPosition() const {return m_currentPosition;}
    bool setCurrentPosition(OpcUa_UInt32 index);

    /** Get the total number of RelativePathElements in the array.
     *  @return The number of elements.
     */
    inline OpcUa_UInt32 pathElementCount() const { return m_noOfElements;};

    const OpcUa_RelativePathElement* getElementAtCurrentPosition() const;
    const OpcUa_RelativePathElement* getElementAt(OpcUa_UInt32 index) const;

    void addNodeManagerToProcess(NodeManager*   pNodeManager,
                                 UaNodeId       startingNode,
                                 OpcUa_UInt32   indexToContinue);
    std::list<UaTranslateBrowsePathContext*> getNodeManagerTranslateContexts() const;
    OpcUa_UInt32 numNodeManagerTranslateContexts() const;
    void clearNodeManagersToProcess();

    void toVariant(UaVariant &variant) const;
    void toVariant(OpcUa_Variant &variant) const;
    void toVariant(UaVariant &variant, OpcUa_Boolean bDetach);
    void toVariant(OpcUa_Variant &variant, OpcUa_Boolean bDetach);

    void toDataValue(UaDataValue &dataValue, OpcUa_Boolean updateTimeStamps) const;
    void toDataValue(OpcUa_DataValue &dataValue, OpcUa_Boolean updateTimeStamps) const;
    void toDataValue(UaDataValue &dataValue, OpcUa_Boolean bDetach, OpcUa_Boolean updateTimeStamps);
    void toDataValue(OpcUa_DataValue &dataValue, OpcUa_Boolean bDetach, OpcUa_Boolean updateTimeStamps);

    void toExtensionObject(UaExtensionObject &extensionObject) const;
    void toExtensionObject(OpcUa_ExtensionObject &extensionObject) const;
    void toExtensionObject(UaExtensionObject &extensionObject, OpcUa_Boolean bDetach);
    void toExtensionObject(OpcUa_ExtensionObject &extensionObject, OpcUa_Boolean bDetach);

    OpcUa_StatusCode setRelativePath(const UaExtensionObject &extensionObject);
    OpcUa_StatusCode setRelativePath(const OpcUa_ExtensionObject &extensionObject);
    OpcUa_StatusCode setRelativePath(UaExtensionObject &extensionObject, OpcUa_Boolean bDetach);
    OpcUa_StatusCode setRelativePath(OpcUa_ExtensionObject &extensionObject, OpcUa_Boolean bDetach);
    void setRelativePath(const OpcUa_RelativePath& relativePath);
    void setRelativePath(const UaRelativePathElements& elements);

private:
    OpcUa_UInt32               m_currentPosition;
    OpcUa_UInt32               m_noOfElements;
    OpcUa_RelativePathElement* m_Elements;
    std::list<UaTranslateBrowsePathContext*> m_lstNodeManagersToContinue;  // a list of nodemanagers we need to query at this position
};

#endif // OPCUATYPES_H
