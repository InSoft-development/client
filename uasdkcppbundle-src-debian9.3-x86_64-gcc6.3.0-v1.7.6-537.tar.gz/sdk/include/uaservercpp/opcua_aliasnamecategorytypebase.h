/******************************************************************************
** opcua_aliasnamecategorytypebase.h
**
** Copyright (c) 2006-2022 Unified Automation GmbH. All rights reserved.
**
** Software License Agreement ("SLA") Version 2.7
**
** Unless explicitly acquired and licensed from Licensor under another
** license, the contents of this file are subject to the Software License
** Agreement ("SLA") Version 2.7, or subsequent versions
** as allowed by the SLA, and You may not copy or use this file in either
** source code or executable form, except in compliance with the terms and
** conditions of the SLA.
**
** All software distributed under the SLA is provided strictly on an
** "AS IS" basis, WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESS OR IMPLIED,
** AND LICENSOR HEREBY DISCLAIMS ALL SUCH WARRANTIES, INCLUDING WITHOUT
** LIMITATION, ANY WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
** PURPOSE, QUIET ENJOYMENT, OR NON-INFRINGEMENT. See the SLA for specific
** language governing rights and limitations under the SLA.
**
** The complete license agreement can be found here:
** http://unifiedautomation.com/License/SLA/2.7/
**
** Project: C++ OPC Server SDK information model for namespace http://opcfoundation.org/UA/
**
** Description: OPC Unified Architecture Software Development Kit.
**
******************************************************************************/

#ifndef __OPCUA_ALIASNAMECATEGORYTYPEBASE_H__
#define __OPCUA_ALIASNAMECATEGORYTYPEBASE_H__

#include "opcua_foldertype.h"
#include "basenodes.h"
#include "opcua_identifiers.h"
#include "opcua_propertytype.h"
#include "uaaliasnamedatatype.h"
#include "uaargument.h"

// Namespace for the UA information model http://opcfoundation.org/UA/
namespace OpcUa {

class AliasNameCategoryType;
class AliasNameType;

/** Generated base class for a AliasNameCategoryType.
 *
 *  This class contains the generated base code for the object type AliasNameCategoryType
 *  representing an OPC UA ObjectType. This class is used to create the object type and to
 *  create and represent instances of the object type in the server address space.
 *
 *  **Object members of the AliasNameCategoryType:**
 *
 *  Browse Name                | TypeDefinition        | Modelling Rule      | See Also
 *  ---------------------------|-----------------------|---------------------|---------
 *  \<Alias\>                  | AliasNameType         | OptionalPlaceholder | &nbsp;
 *  \<SubAliasNameCategories\> | AliasNameCategoryType | OptionalPlaceholder | &nbsp;
 *
 *  https://reference.opcfoundation.org/v104/Core/docs/Part17/6.3.1
 *
 *  See also \ref Doc_OpcUa_AliasNameCategoryType for a documentation of the complete Information Model.
 */
class SERVER_CORE_EXPORT AliasNameCategoryTypeBase:
    public OpcUa::FolderType
{
    UA_DISABLE_COPY(AliasNameCategoryTypeBase);
protected:
    virtual ~AliasNameCategoryTypeBase();
public:
    // construction / destruction
    AliasNameCategoryTypeBase(const UaNodeId& nodeId, UaObject* pInstanceDeclarationObject, NodeManagerConfig* pNodeConfig, UaMutexRefCounted* pSharedMutex = NULL);
    AliasNameCategoryTypeBase(const UaNodeId& nodeId, const UaString& name, OpcUa_UInt16 browseNameNameSpaceIndex, NodeManagerConfig* pNodeConfig, UaMutexRefCounted* pSharedMutex = NULL);
    AliasNameCategoryTypeBase(
        UaBase::Object*    pBaseNode,
        XmlUaNodeFactoryManager*   pFactory,
        NodeManagerConfig* pNodeConfig,
        UaMutexRefCounted* pSharedMutex = NULL);
    static void createTypes();
    static void clearStaticMembers();

    virtual UaNodeId       typeDefinitionId() const;


    //- Interface MethodManager -----------------------------------------------------------
    /** Call method of an UA object. */
    virtual UaStatus beginCall(
        MethodManagerCallback* pCallback,
        const ServiceContext&  serviceContext,
        OpcUa_UInt32           callbackHandle,
        MethodHandle*          pMethodHandle,
        const UaVariantArray&  inputArguments);
    virtual UaStatus call(
        const ServiceContext&  serviceContext,
        MethodHandle*          pMethodHandle,
        const UaVariantArray&  inputArguments,
        UaVariantArray&        outputArguments,
        UaStatusCodeArray&     inputArgumentResults,
        UaDiagnosticInfos&     inputArgumentDiag);
    //- Interface MethodManager -----------------------------------------------------------

    virtual UaStatus FindAlias(
        const ServiceContext& serviceContext /**<General context for the service calls containing
                                                 information like the session object,
                                                 return diagnostic mask and timeout hint.*/,
        const UaString& AliasNameSearchPattern,
        const UaNodeId& ReferenceTypeFilter,
        UaAliasNameDataTypes& AliasNodeList) = 0;

    virtual OpcUa::BaseMethod* getFindAlias();
    virtual const OpcUa::BaseMethod* getFindAlias() const;

// Add placeholders
    virtual UaStatus addAlias_Placeholder(OpcUa::AliasNameType *pAlias_Placeholder);
    virtual UaStatus addSubAliasNameCategories_Placeholder(OpcUa::AliasNameCategoryType *pSubAliasNameCategories_Placeholder);

    // NodeAccessInfo management
    virtual void useAccessInfoFromType();
    void useAccessInfoFromInstance(AliasNameCategoryTypeBase *pInstance);

protected:
    // Object nodes
    // Object Alias_Placeholder
    static OpcUa::AliasNameType*  s_pAlias_Placeholder;
    // Object SubAliasNameCategories_Placeholder
    static OpcUa::AliasNameCategoryType*  s_pSubAliasNameCategories_Placeholder;


    // Method nodes
    static OpcUa::BaseMethod* s_pFindAliasMethod;
    OpcUa::BaseMethod*  m_pFindAliasMethod;


private:
    void initialize();

private:
    static bool s_typeNodesCreated;
};

} // End namespace for the UA information model http://opcfoundation.org/UA/

#endif // #ifndef __OPCUAALIASNAMECATEGORYTYPEBASE_H__


