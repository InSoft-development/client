/******************************************************************************
** opcua_programdiagnostic2type.h
**
** Copyright (c) 2006-2022 Unified Automation GmbH. All rights reserved.
**
** Software License Agreement ("SLA") Version 2.7
**
** Unless explicitly acquired and licensed from Licensor under another
** license, the contents of this file are subject to the Software License
** Agreement ("SLA") Version 2.7, or subsequent versions
** as allowed by the SLA, and You may not copy or use this file in either
** source code or executable form, except in compliance with the terms and
** conditions of the SLA.
**
** All software distributed under the SLA is provided strictly on an
** "AS IS" basis, WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESS OR IMPLIED,
** AND LICENSOR HEREBY DISCLAIMS ALL SUCH WARRANTIES, INCLUDING WITHOUT
** LIMITATION, ANY WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
** PURPOSE, QUIET ENJOYMENT, OR NON-INFRINGEMENT. See the SLA for specific
** language governing rights and limitations under the SLA.
**
** The complete license agreement can be found here:
** http://unifiedautomation.com/License/SLA/2.7/
**
** Project: C++ OPC Server SDK information model for namespace http://opcfoundation.org/UA/
**
** Description: OPC Unified Architecture Software Development Kit.
**
******************************************************************************/

#ifndef __OPCUA_PROGRAMDIAGNOSTIC2TYPE_H__
#define __OPCUA_PROGRAMDIAGNOSTIC2TYPE_H__

#include "opcua_basedatavariabletype.h"
#include "opcua_identifiers.h"
#include "uaargument.h"

// Namespace for the UA information model http://opcfoundation.org/UA/
namespace OpcUa {

class BaseDataVariableType;
class PropertyType;

/** Implements OPC UA Variables of the type ProgramDiagnostic2Type
 *
 *  **Variable members of the ProgramDiagnostic2Type:**
 *
 *  Browse Name               | DataType     | TypeDefinition       | Modelling Rule | See Also
 *  --------------------------|--------------|----------------------|----------------|---------------------------------------------------------------------
 *  CreateClientName          | String       | BaseDataVariableType | Mandatory      | \ref getCreateClientName, \ref setCreateClientName
 *  CreateSessionId           | NodeId       | BaseDataVariableType | Mandatory      | \ref getCreateSessionId, \ref setCreateSessionId
 *  InvocationCreationTime    | UtcTime      | BaseDataVariableType | Mandatory      | \ref getInvocationCreationTime, \ref setInvocationCreationTime
 *  LastMethodCall            | String       | BaseDataVariableType | Mandatory      | \ref getLastMethodCall, \ref setLastMethodCall
 *  LastMethodCallTime        | UtcTime      | BaseDataVariableType | Mandatory      | \ref getLastMethodCallTime, \ref setLastMethodCallTime
 *  LastMethodInputArguments  | Argument     | BaseDataVariableType | Mandatory      | \ref getLastMethodInputArguments, \ref setLastMethodInputArguments
 *  LastMethodInputValues     | BaseDataType | BaseDataVariableType | Mandatory      | \ref getLastMethodInputValues, \ref setLastMethodInputValues
 *  LastMethodOutputArguments | Argument     | BaseDataVariableType | Mandatory      | \ref getLastMethodOutputArguments, \ref setLastMethodOutputArguments
 *  LastMethodOutputValues    | BaseDataType | BaseDataVariableType | Mandatory      | \ref getLastMethodOutputValues, \ref setLastMethodOutputValues
 *  LastMethodReturnStatus    | StatusCode   | BaseDataVariableType | Mandatory      | \ref getLastMethodReturnStatus, \ref setLastMethodReturnStatus
 *  LastMethodSessionId       | NodeId       | BaseDataVariableType | Mandatory      | \ref getLastMethodSessionId, \ref setLastMethodSessionId
 *  LastTransitionTime        | UtcTime      | PropertyType         | Mandatory      | \ref getLastTransitionTime, \ref setLastTransitionTime
 *
 *  https://reference.opcfoundation.org/v104/Core/docs/Part10/5.2.9
 *
 *  See also \ref Doc_OpcUa_ProgramDiagnostic2Type for a documentation of the complete Information Model.
 */
class SERVER_CORE_EXPORT ProgramDiagnostic2Type:
    public OpcUa::BaseDataVariableType
{
    UA_DISABLE_COPY(ProgramDiagnostic2Type);
protected:
    virtual ~ProgramDiagnostic2Type();
public:
    ProgramDiagnostic2Type(
        UaNode*            pParentNode,
        UaVariable*        pInstanceDeclarationVariable,
        NodeManagerConfig* pNodeConfig,
        UaMutexRefCounted* pSharedMutex = NULL);
    ProgramDiagnostic2Type(
        const UaNodeId&    nodeId,
        const UaString&    name,
        OpcUa_UInt16       browseNameNameSpaceIndex,
        const UaVariant&   initialValue,
        OpcUa_Byte         accessLevel,
        NodeManagerConfig* pNodeConfig,
        UaMutexRefCounted* pSharedMutex = NULL);
    ProgramDiagnostic2Type(
        UaBase::Variable*  pBaseNode,
        XmlUaNodeFactoryManager*   pFactory,
        NodeManagerConfig* pNodeConfig,
        UaMutexRefCounted* pSharedMutex = NULL);

    static void createTypes();
    static void clearStaticMembers();

    virtual UaNodeId       typeDefinitionId() const;

    virtual void setCreateClientName(const UaString& CreateClientName);
    virtual UaString getCreateClientName() const;

    virtual void setCreateSessionId(const UaNodeId& CreateSessionId);
    virtual UaNodeId getCreateSessionId() const;

    virtual void setInvocationCreationTime(const UaDateTime& InvocationCreationTime);
    virtual UaDateTime getInvocationCreationTime() const;

    virtual void setLastMethodCall(const UaString& LastMethodCall);
    virtual UaString getLastMethodCall() const;

    virtual void setLastMethodCallTime(const UaDateTime& LastMethodCallTime);
    virtual UaDateTime getLastMethodCallTime() const;

    virtual void setLastMethodInputArguments(const UaArguments& LastMethodInputArguments);
    virtual void getLastMethodInputArguments(UaArguments& LastMethodInputArguments) const;

    virtual void setLastMethodInputValues(const UaVariantArray& LastMethodInputValues);
    virtual void getLastMethodInputValues(UaVariantArray& LastMethodInputValues) const;

    virtual void setLastMethodOutputArguments(const UaArguments& LastMethodOutputArguments);
    virtual void getLastMethodOutputArguments(UaArguments& LastMethodOutputArguments) const;

    virtual void setLastMethodOutputValues(const UaVariantArray& LastMethodOutputValues);
    virtual void getLastMethodOutputValues(UaVariantArray& LastMethodOutputValues) const;

    virtual void setLastMethodReturnStatus(OpcUa_StatusCode LastMethodReturnStatus);
    virtual OpcUa_StatusCode getLastMethodReturnStatus() const;

    virtual void setLastMethodSessionId(const UaNodeId& LastMethodSessionId);
    virtual UaNodeId getLastMethodSessionId() const;

    virtual void setLastTransitionTime(const UaDateTime& LastTransitionTime);
    virtual UaDateTime getLastTransitionTime() const;

    virtual OpcUa::BaseDataVariableType* getCreateClientNameNode();
    virtual const OpcUa::BaseDataVariableType* getCreateClientNameNode() const;
    virtual OpcUa::BaseDataVariableType* getCreateSessionIdNode();
    virtual const OpcUa::BaseDataVariableType* getCreateSessionIdNode() const;
    virtual OpcUa::BaseDataVariableType* getInvocationCreationTimeNode();
    virtual const OpcUa::BaseDataVariableType* getInvocationCreationTimeNode() const;
    virtual OpcUa::BaseDataVariableType* getLastMethodCallNode();
    virtual const OpcUa::BaseDataVariableType* getLastMethodCallNode() const;
    virtual OpcUa::BaseDataVariableType* getLastMethodCallTimeNode();
    virtual const OpcUa::BaseDataVariableType* getLastMethodCallTimeNode() const;
    virtual OpcUa::BaseDataVariableType* getLastMethodInputArgumentsNode();
    virtual const OpcUa::BaseDataVariableType* getLastMethodInputArgumentsNode() const;
    virtual OpcUa::BaseDataVariableType* getLastMethodInputValuesNode();
    virtual const OpcUa::BaseDataVariableType* getLastMethodInputValuesNode() const;
    virtual OpcUa::BaseDataVariableType* getLastMethodOutputArgumentsNode();
    virtual const OpcUa::BaseDataVariableType* getLastMethodOutputArgumentsNode() const;
    virtual OpcUa::BaseDataVariableType* getLastMethodOutputValuesNode();
    virtual const OpcUa::BaseDataVariableType* getLastMethodOutputValuesNode() const;
    virtual OpcUa::BaseDataVariableType* getLastMethodReturnStatusNode();
    virtual const OpcUa::BaseDataVariableType* getLastMethodReturnStatusNode() const;
    virtual OpcUa::BaseDataVariableType* getLastMethodSessionIdNode();
    virtual const OpcUa::BaseDataVariableType* getLastMethodSessionIdNode() const;
    virtual OpcUa::PropertyType* getLastTransitionTimeNode();
    virtual const OpcUa::PropertyType* getLastTransitionTimeNode() const;

protected:
    // Variable nodes
    // Variable CreateClientName
    static OpcUa::BaseDataVariableType*  s_pCreateClientName;
    OpcUa::BaseDataVariableType*  m_pCreateClientName;
    // Variable CreateSessionId
    static OpcUa::BaseDataVariableType*  s_pCreateSessionId;
    OpcUa::BaseDataVariableType*  m_pCreateSessionId;
    // Variable InvocationCreationTime
    static OpcUa::BaseDataVariableType*  s_pInvocationCreationTime;
    OpcUa::BaseDataVariableType*  m_pInvocationCreationTime;
    // Variable LastMethodCall
    static OpcUa::BaseDataVariableType*  s_pLastMethodCall;
    OpcUa::BaseDataVariableType*  m_pLastMethodCall;
    // Variable LastMethodCallTime
    static OpcUa::BaseDataVariableType*  s_pLastMethodCallTime;
    OpcUa::BaseDataVariableType*  m_pLastMethodCallTime;
    // Variable LastMethodInputArguments
    static OpcUa::BaseDataVariableType*  s_pLastMethodInputArguments;
    OpcUa::BaseDataVariableType*  m_pLastMethodInputArguments;
    // Variable LastMethodInputValues
    static OpcUa::BaseDataVariableType*  s_pLastMethodInputValues;
    OpcUa::BaseDataVariableType*  m_pLastMethodInputValues;
    // Variable LastMethodOutputArguments
    static OpcUa::BaseDataVariableType*  s_pLastMethodOutputArguments;
    OpcUa::BaseDataVariableType*  m_pLastMethodOutputArguments;
    // Variable LastMethodOutputValues
    static OpcUa::BaseDataVariableType*  s_pLastMethodOutputValues;
    OpcUa::BaseDataVariableType*  m_pLastMethodOutputValues;
    // Variable LastMethodReturnStatus
    static OpcUa::BaseDataVariableType*  s_pLastMethodReturnStatus;
    OpcUa::BaseDataVariableType*  m_pLastMethodReturnStatus;
    // Variable LastMethodSessionId
    static OpcUa::BaseDataVariableType*  s_pLastMethodSessionId;
    OpcUa::BaseDataVariableType*  m_pLastMethodSessionId;
    // Variable LastTransitionTime
    static OpcUa::PropertyType*  s_pLastTransitionTime;
    OpcUa::PropertyType*  m_pLastTransitionTime;


private:
    void initialize(NodeManagerConfig* pNodeConfig);

private:
    static bool s_typeNodesCreated;
};

} // End namespace for the UA information model http://opcfoundation.org/UA/

#endif // #ifndef __OPCUA_PROGRAMDIAGNOSTIC2TYPE_H__

