/******************************************************************************
** Copyright (c) 2016-2022 Unified Automation GmbH. All rights reserved.
**
** Software License Agreement ("SLA") Version 2.7
**
** Unless explicitly acquired and licensed from Licensor under another
** license, the contents of this file are subject to the Software License
** Agreement ("SLA") Version 2.7, or subsequent versions
** as allowed by the SLA, and You may not copy or use this file in either
** source code or executable form, except in compliance with the terms and
** conditions of the SLA.
**
** All software distributed under the SLA is provided strictly on an
** "AS IS" basis, WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESS OR IMPLIED,
** AND LICENSOR HEREBY DISCLAIMS ALL SUCH WARRANTIES, INCLUDING WITHOUT
** LIMITATION, ANY WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
** PURPOSE, QUIET ENJOYMENT, OR NON-INFRINGEMENT. See the SLA for specific
** language governing rights and limitations under the SLA.
**
** The complete license agreement can be found here:
** http://unifiedautomation.com/License/SLA/2.7/
**
** Project: C++ OPC Server SDK core module
**
******************************************************************************/
#ifndef _NODESETBROWSEIMPORT_H_
#define _NODESETBROWSEIMPORT_H_

#include "abstractnodesetbrowseimport.h"
#include <servermanager.h>

namespace UaServerCore
{

/** Server side implementation of a Nodeset Browse/Read importer.
*/
class SERVER_CORE_EXPORT NodesetBrowseImport :
    public UaBase::AbstractNodesetBrowseImport
{
public:
    NodesetBrowseImport(Session* pSession);
    ~NodesetBrowseImport();

protected:
    // Interface AbstractNodesetBrowseImport
    virtual bool browseList(const UaNodeIdArray& nodeIds, UaBrowseResults &targetNodes);
    virtual bool read(UaBase::BaseNode* nodes[], UaDataValues &attributes);
    virtual UaStringArray readNamespaceTable();

    UaReadValueIds getAttributes(UaBase::BaseNode *nodeIds[]) const;

private:
    // Config for connection
    ServerManager* m_pServerManager;
    Session* m_pSession;

    bool extractCPs(const UaBrowseResults &targetNodes, UaBooleanArray &resultHasCP, UaByteStringArray &continuationPoints) const;
};

} // end namespace UaServerCore

#endif //_NODESETBROWSEIMPORT_H_
