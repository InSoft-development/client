/******************************************************************************
** opcuadi_instancefactory_devices.h
**
** Copyright (c) 2006-2022 Unified Automation GmbH. All rights reserved.
**
** Software License Agreement ("SLA") Version 2.7
**
** Unless explicitly acquired and licensed from Licensor under another
** license, the contents of this file are subject to the Software License
** Agreement ("SLA") Version 2.7, or subsequent versions
** as allowed by the SLA, and You may not copy or use this file in either
** source code or executable form, except in compliance with the terms and
** conditions of the SLA.
**
** All software distributed under the SLA is provided strictly on an
** "AS IS" basis, WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESS OR IMPLIED,
** AND LICENSOR HEREBY DISCLAIMS ALL SUCH WARRANTIES, INCLUDING WITHOUT
** LIMITATION, ANY WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
** PURPOSE, QUIET ENJOYMENT, OR NON-INFRINGEMENT. See the SLA for specific
** language governing rights and limitations under the SLA.
**
** The complete license agreement can be found here:
** http://unifiedautomation.com/License/SLA/2.7/
**
** Project: C++ OPC Server SDK information model for namespace http://opcfoundation.org/UA/DI/
**
** Description: OPC Unified Architecture Software Development Kit.
**
******************************************************************************/


#ifndef __INSTSTANCEFACTORY_Devices_
#define __INSTSTANCEFACTORY_Devices_
#include <basenodes.h>
#include "opcua_basevariabletype.h"
#include "opcua_baseobjecttype.h"
#include <instancefactory.h>
#include "opcuadi_identifiers.h"

class XmlUaNodeFactoryManager;

namespace OpcUaDi
{

class UAMODELS_EXPORT InstanceFactoryDevices : public XmlUaNodeFactoryNamespace
{
public:
    InstanceFactoryDevices();
    InstanceFactoryDevices(OpcUa_UInt16 namespaceIndex);

    virtual OpcUa::BaseVariableType* createVariable(
        UaBase::Variable *pVariable,
        XmlUaNodeFactoryManager *pFactory,
        NodeManagerConfig* pNodeConfig,
        UaMutexRefCounted* pSharedMutex = NULL);
    virtual OpcUa::BaseObjectType* createObject(
        UaBase::Object *pObject,
        XmlUaNodeFactoryManager *pFactory,
        NodeManagerConfig* pNodeConfig,
        UaMutexRefCounted* pSharedMutex = NULL);
    virtual UaVariant defaultValue(const UaNodeId &dataTypeId, OpcUa_Int32 valueRank) const;
    virtual void createType(const UaNodeId &typeId) const;
};

};
#endif //__INSTSTANCEFACTORY_Devices_
